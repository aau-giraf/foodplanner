//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class Meal {
  /// Returns a new [Meal] instance.
  Meal({
    this.id,
    this.name,
    this.userId,
    this.foodImageId,
    this.date,
  });

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? id;

  String? name;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? userId;

  int? foodImageId;

  String? date;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Meal &&
          other.id == id &&
          other.name == name &&
          other.userId == userId &&
          other.foodImageId == foodImageId &&
          other.date == date;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (id == null ? 0 : id!.hashCode) +
      (name == null ? 0 : name!.hashCode) +
      (userId == null ? 0 : userId!.hashCode) +
      (foodImageId == null ? 0 : foodImageId!.hashCode) +
      (date == null ? 0 : date!.hashCode);

  @override
  String toString() =>
      'Meal[id=$id, name=$name, userId=$userId, foodImageId=$foodImageId, date=$date]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    if (this.id != null) {
      json[r'id'] = this.id;
    } else {
      json[r'id'] = null;
    }
    if (this.name != null) {
      json[r'name'] = this.name;
    } else {
      json[r'name'] = null;
    }
    if (this.userId != null) {
      json[r'user_id'] = this.userId;
    } else {
      json[r'user_id'] = null;
    }
    if (this.foodImageId != null) {
      json[r'food_image_id'] = this.foodImageId;
    } else {
      json[r'food_image_id'] = null;
    }
    if (this.date != null) {
      json[r'date'] = this.date;
    } else {
      json[r'date'] = null;
    }
    return json;
  }

  /// Returns a new [Meal] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static Meal? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "Meal[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "Meal[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return Meal(
        id: mapValueOfType<int>(json, r'id'),
        name: mapValueOfType<String>(json, r'name'),
        userId: mapValueOfType<int>(json, r'user_id'),
        foodImageId: mapValueOfType<int>(json, r'food_image_id'),
        date: mapValueOfType<String>(json, r'date'),
      );
    }
    return null;
  }

  static List<Meal> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <Meal>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = Meal.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, Meal> mapFromJson(dynamic json) {
    final map = <String, Meal>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = Meal.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of Meal-objects as value to a dart map
  static Map<String, List<Meal>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<Meal>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = Meal.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{};
}
