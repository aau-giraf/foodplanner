//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class ChildrenGetAllDTO {
  /// Returns a new [ChildrenGetAllDTO] instance.
  ChildrenGetAllDTO({
    this.childId,
    this.firstName,
    this.lastName,
    this.className,
    this.classId,
  });

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? childId;

  String? firstName;

  String? lastName;

  String? className;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? classId;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ChildrenGetAllDTO &&
          other.childId == childId &&
          other.firstName == firstName &&
          other.lastName == lastName &&
          other.className == className &&
          other.classId == classId;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (childId == null ? 0 : childId!.hashCode) +
      (firstName == null ? 0 : firstName!.hashCode) +
      (lastName == null ? 0 : lastName!.hashCode) +
      (className == null ? 0 : className!.hashCode) +
      (classId == null ? 0 : classId!.hashCode);

  @override
  String toString() =>
      'ChildrenGetAllDTO[childId=$childId, firstName=$firstName, lastName=$lastName, className=$className, classId=$classId]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    if (this.childId != null) {
      json[r'childId'] = this.childId;
    } else {
      json[r'childId'] = null;
    }
    if (this.firstName != null) {
      json[r'firstName'] = this.firstName;
    } else {
      json[r'firstName'] = null;
    }
    if (this.lastName != null) {
      json[r'lastName'] = this.lastName;
    } else {
      json[r'lastName'] = null;
    }
    if (this.className != null) {
      json[r'className'] = this.className;
    } else {
      json[r'className'] = null;
    }
    if (this.classId != null) {
      json[r'classId'] = this.classId;
    } else {
      json[r'classId'] = null;
    }
    return json;
  }

  /// Returns a new [ChildrenGetAllDTO] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static ChildrenGetAllDTO? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "ChildrenGetAllDTO[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "ChildrenGetAllDTO[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return ChildrenGetAllDTO(
        childId: mapValueOfType<int>(json, r'childId'),
        firstName: mapValueOfType<String>(json, r'firstName'),
        lastName: mapValueOfType<String>(json, r'lastName'),
        className: mapValueOfType<String>(json, r'className'),
        classId: mapValueOfType<int>(json, r'classId'),
      );
    }
    return null;
  }

  static List<ChildrenGetAllDTO> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <ChildrenGetAllDTO>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = ChildrenGetAllDTO.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, ChildrenGetAllDTO> mapFromJson(dynamic json) {
    final map = <String, ChildrenGetAllDTO>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = ChildrenGetAllDTO.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of ChildrenGetAllDTO-objects as value to a dart map
  static Map<String, List<ChildrenGetAllDTO>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<ChildrenGetAllDTO>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = ChildrenGetAllDTO.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{};
}
