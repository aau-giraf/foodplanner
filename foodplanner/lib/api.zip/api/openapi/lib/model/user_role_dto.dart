//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class UserRoleDTO {
  /// Returns a new [UserRoleDTO] instance.
  UserRoleDTO({
    this.id,
    this.roleApproved,
  });

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? id;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  bool? roleApproved;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is UserRoleDTO &&
          other.id == id &&
          other.roleApproved == roleApproved;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (id == null ? 0 : id!.hashCode) +
      (roleApproved == null ? 0 : roleApproved!.hashCode);

  @override
  String toString() => 'UserRoleDTO[id=$id, roleApproved=$roleApproved]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    if (this.id != null) {
      json[r'id'] = this.id;
    } else {
      json[r'id'] = null;
    }
    if (this.roleApproved != null) {
      json[r'role_approved'] = this.roleApproved;
    } else {
      json[r'role_approved'] = null;
    }
    return json;
  }

  /// Returns a new [UserRoleDTO] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static UserRoleDTO? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "UserRoleDTO[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "UserRoleDTO[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return UserRoleDTO(
        id: mapValueOfType<int>(json, r'id'),
        roleApproved: mapValueOfType<bool>(json, r'role_approved'),
      );
    }
    return null;
  }

  static List<UserRoleDTO> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <UserRoleDTO>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = UserRoleDTO.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, UserRoleDTO> mapFromJson(dynamic json) {
    final map = <String, UserRoleDTO>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = UserRoleDTO.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of UserRoleDTO-objects as value to a dart map
  static Map<String, List<UserRoleDTO>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<UserRoleDTO>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = UserRoleDTO.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{};
}
