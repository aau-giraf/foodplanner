//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class MealCreateDTO {
  /// Returns a new [MealCreateDTO] instance.
  MealCreateDTO({
    this.foodImageId,
    this.name,
    this.date,
  });

  int? foodImageId;

  String? name;

  String? date;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MealCreateDTO &&
          other.foodImageId == foodImageId &&
          other.name == name &&
          other.date == date;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (foodImageId == null ? 0 : foodImageId!.hashCode) +
      (name == null ? 0 : name!.hashCode) +
      (date == null ? 0 : date!.hashCode);

  @override
  String toString() =>
      'MealCreateDTO[foodImageId=$foodImageId, name=$name, date=$date]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    if (this.foodImageId != null) {
      json[r'food_image_id'] = this.foodImageId;
    } else {
      json[r'food_image_id'] = null;
    }
    if (this.name != null) {
      json[r'name'] = this.name;
    } else {
      json[r'name'] = null;
    }
    if (this.date != null) {
      json[r'date'] = this.date;
    } else {
      json[r'date'] = null;
    }
    return json;
  }

  /// Returns a new [MealCreateDTO] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static MealCreateDTO? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "MealCreateDTO[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "MealCreateDTO[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return MealCreateDTO(
        foodImageId: mapValueOfType<int>(json, r'food_image_id'),
        name: mapValueOfType<String>(json, r'name'),
        date: mapValueOfType<String>(json, r'date'),
      );
    }
    return null;
  }

  static List<MealCreateDTO> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <MealCreateDTO>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = MealCreateDTO.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, MealCreateDTO> mapFromJson(dynamic json) {
    final map = <String, MealCreateDTO>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = MealCreateDTO.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of MealCreateDTO-objects as value to a dart map
  static Map<String, List<MealCreateDTO>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<MealCreateDTO>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = MealCreateDTO.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{};
}
