//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class Pincode {
  /// Returns a new [Pincode] instance.
  Pincode({
    this.pinCode,
  });

  String? pinCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is Pincode && other.pinCode == pinCode;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (pinCode == null ? 0 : pinCode!.hashCode);

  @override
  String toString() => 'Pincode[pinCode=$pinCode]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    if (this.pinCode != null) {
      json[r'pinCode'] = this.pinCode;
    } else {
      json[r'pinCode'] = null;
    }
    return json;
  }

  /// Returns a new [Pincode] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static Pincode? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "Pincode[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "Pincode[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return Pincode(
        pinCode: mapValueOfType<String>(json, r'pinCode'),
      );
    }
    return null;
  }

  static List<Pincode> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <Pincode>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = Pincode.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, Pincode> mapFromJson(dynamic json) {
    final map = <String, Pincode>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = Pincode.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of Pincode-objects as value to a dart map
  static Map<String, List<Pincode>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<Pincode>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = Pincode.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{};
}
