//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class User {
  /// Returns a new [User] instance.
  User({
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.password,
    required this.role,
    this.id,
    this.roleApproved,
    this.pinCode,
    this.archived,
  });

  String firstName;

  String lastName;

  String email;

  String password;

  String role;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? id;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  bool? roleApproved;

  String? pinCode;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  bool? archived;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is User &&
          other.firstName == firstName &&
          other.lastName == lastName &&
          other.email == email &&
          other.password == password &&
          other.role == role &&
          other.id == id &&
          other.roleApproved == roleApproved &&
          other.pinCode == pinCode &&
          other.archived == archived;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (firstName.hashCode) +
      (lastName.hashCode) +
      (email.hashCode) +
      (password.hashCode) +
      (role.hashCode) +
      (id == null ? 0 : id!.hashCode) +
      (roleApproved == null ? 0 : roleApproved!.hashCode) +
      (pinCode == null ? 0 : pinCode!.hashCode) +
      (archived == null ? 0 : archived!.hashCode);

  @override
  String toString() =>
      'User[firstName=$firstName, lastName=$lastName, email=$email, password=$password, role=$role, id=$id, roleApproved=$roleApproved, pinCode=$pinCode, archived=$archived]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    json[r'firstName'] = this.firstName;
    json[r'lastName'] = this.lastName;
    json[r'email'] = this.email;
    json[r'password'] = this.password;
    json[r'role'] = this.role;
    if (this.id != null) {
      json[r'id'] = this.id;
    } else {
      json[r'id'] = null;
    }
    if (this.roleApproved != null) {
      json[r'roleApproved'] = this.roleApproved;
    } else {
      json[r'roleApproved'] = null;
    }
    if (this.pinCode != null) {
      json[r'pinCode'] = this.pinCode;
    } else {
      json[r'pinCode'] = null;
    }
    if (this.archived != null) {
      json[r'archived'] = this.archived;
    } else {
      json[r'archived'] = null;
    }
    return json;
  }

  /// Returns a new [User] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static User? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "User[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "User[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return User(
        firstName: mapValueOfType<String>(json, r'firstName')!,
        lastName: mapValueOfType<String>(json, r'lastName')!,
        email: mapValueOfType<String>(json, r'email')!,
        password: mapValueOfType<String>(json, r'password')!,
        role: mapValueOfType<String>(json, r'role')!,
        id: mapValueOfType<int>(json, r'id'),
        roleApproved: mapValueOfType<bool>(json, r'roleApproved'),
        pinCode: mapValueOfType<String>(json, r'pinCode'),
        archived: mapValueOfType<bool>(json, r'archived'),
      );
    }
    return null;
  }

  static List<User> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <User>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = User.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, User> mapFromJson(dynamic json) {
    final map = <String, User>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = User.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of User-objects as value to a dart map
  static Map<String, List<User>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<User>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = User.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{
    'firstName',
    'lastName',
    'email',
    'password',
    'role',
  };
}
