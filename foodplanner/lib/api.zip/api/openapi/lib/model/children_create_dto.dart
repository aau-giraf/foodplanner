//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class ChildrenCreateDTO {
  /// Returns a new [ChildrenCreateDTO] instance.
  ChildrenCreateDTO({
    required this.firstName,
    required this.lastName,
    required this.classId,
  });

  String firstName;

  String lastName;

  int classId;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ChildrenCreateDTO &&
          other.firstName == firstName &&
          other.lastName == lastName &&
          other.classId == classId;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (firstName.hashCode) + (lastName.hashCode) + (classId.hashCode);

  @override
  String toString() =>
      'ChildrenCreateDTO[firstName=$firstName, lastName=$lastName, classId=$classId]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    json[r'firstName'] = this.firstName;
    json[r'lastName'] = this.lastName;
    json[r'classId'] = this.classId;
    return json;
  }

  /// Returns a new [ChildrenCreateDTO] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static ChildrenCreateDTO? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "ChildrenCreateDTO[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "ChildrenCreateDTO[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return ChildrenCreateDTO(
        firstName: mapValueOfType<String>(json, r'firstName')!,
        lastName: mapValueOfType<String>(json, r'lastName')!,
        classId: mapValueOfType<int>(json, r'classId')!,
      );
    }
    return null;
  }

  static List<ChildrenCreateDTO> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <ChildrenCreateDTO>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = ChildrenCreateDTO.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, ChildrenCreateDTO> mapFromJson(dynamic json) {
    final map = <String, ChildrenCreateDTO>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = ChildrenCreateDTO.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of ChildrenCreateDTO-objects as value to a dart map
  static Map<String, List<ChildrenCreateDTO>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<ChildrenCreateDTO>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = ChildrenCreateDTO.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{
    'firstName',
    'lastName',
    'classId',
  };
}
