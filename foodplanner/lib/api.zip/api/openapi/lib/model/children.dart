//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class Children {
  /// Returns a new [Children] instance.
  Children({
    required this.firstName,
    required this.lastName,
    this.childId,
    this.parentId,
    this.classId,
  });

  String firstName;

  String lastName;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? childId;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? parentId;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? classId;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Children &&
          other.firstName == firstName &&
          other.lastName == lastName &&
          other.childId == childId &&
          other.parentId == parentId &&
          other.classId == classId;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (firstName.hashCode) +
      (lastName.hashCode) +
      (childId == null ? 0 : childId!.hashCode) +
      (parentId == null ? 0 : parentId!.hashCode) +
      (classId == null ? 0 : classId!.hashCode);

  @override
  String toString() =>
      'Children[firstName=$firstName, lastName=$lastName, childId=$childId, parentId=$parentId, classId=$classId]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    json[r'firstName'] = this.firstName;
    json[r'lastName'] = this.lastName;
    if (this.childId != null) {
      json[r'childId'] = this.childId;
    } else {
      json[r'childId'] = null;
    }
    if (this.parentId != null) {
      json[r'parentId'] = this.parentId;
    } else {
      json[r'parentId'] = null;
    }
    if (this.classId != null) {
      json[r'classId'] = this.classId;
    } else {
      json[r'classId'] = null;
    }
    return json;
  }

  /// Returns a new [Children] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static Children? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "Children[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "Children[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return Children(
        firstName: mapValueOfType<String>(json, r'firstName')!,
        lastName: mapValueOfType<String>(json, r'lastName')!,
        childId: mapValueOfType<int>(json, r'childId'),
        parentId: mapValueOfType<int>(json, r'parentId'),
        classId: mapValueOfType<int>(json, r'classId'),
      );
    }
    return null;
  }

  static List<Children> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <Children>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = Children.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, Children> mapFromJson(dynamic json) {
    final map = <String, Children>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = Children.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of Children-objects as value to a dart map
  static Map<String, List<Children>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<Children>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = Children.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{
    'firstName',
    'lastName',
  };
}
