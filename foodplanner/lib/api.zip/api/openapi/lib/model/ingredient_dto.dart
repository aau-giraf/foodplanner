//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class IngredientDTO {
  /// Returns a new [IngredientDTO] instance.
  IngredientDTO({
    this.name,
    this.foodImageId,
  });

  String? name;

  int? foodImageId;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is IngredientDTO &&
          other.name == name &&
          other.foodImageId == foodImageId;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (name == null ? 0 : name!.hashCode) +
      (foodImageId == null ? 0 : foodImageId!.hashCode);

  @override
  String toString() => 'IngredientDTO[name=$name, foodImageId=$foodImageId]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    if (this.name != null) {
      json[r'name'] = this.name;
    } else {
      json[r'name'] = null;
    }
    if (this.foodImageId != null) {
      json[r'food_image_id'] = this.foodImageId;
    } else {
      json[r'food_image_id'] = null;
    }
    return json;
  }

  /// Returns a new [IngredientDTO] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static IngredientDTO? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "IngredientDTO[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "IngredientDTO[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return IngredientDTO(
        name: mapValueOfType<String>(json, r'name'),
        foodImageId: mapValueOfType<int>(json, r'food_image_id'),
      );
    }
    return null;
  }

  static List<IngredientDTO> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <IngredientDTO>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = IngredientDTO.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, IngredientDTO> mapFromJson(dynamic json) {
    final map = <String, IngredientDTO>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = IngredientDTO.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of IngredientDTO-objects as value to a dart map
  static Map<String, List<IngredientDTO>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<IngredientDTO>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = IngredientDTO.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{};
}
