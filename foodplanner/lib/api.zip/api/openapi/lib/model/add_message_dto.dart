//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class AddMessageDTO {
  /// Returns a new [AddMessageDTO] instance.
  AddMessageDTO({
    this.chatThreadId,
    this.content,
  });

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? chatThreadId;

  String? content;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AddMessageDTO &&
          other.chatThreadId == chatThreadId &&
          other.content == content;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (chatThreadId == null ? 0 : chatThreadId!.hashCode) +
      (content == null ? 0 : content!.hashCode);

  @override
  String toString() =>
      'AddMessageDTO[chatThreadId=$chatThreadId, content=$content]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    if (this.chatThreadId != null) {
      json[r'chatThreadId'] = this.chatThreadId;
    } else {
      json[r'chatThreadId'] = null;
    }
    if (this.content != null) {
      json[r'content'] = this.content;
    } else {
      json[r'content'] = null;
    }
    return json;
  }

  /// Returns a new [AddMessageDTO] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static AddMessageDTO? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "AddMessageDTO[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "AddMessageDTO[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return AddMessageDTO(
        chatThreadId: mapValueOfType<int>(json, r'chatThreadId'),
        content: mapValueOfType<String>(json, r'content'),
      );
    }
    return null;
  }

  static List<AddMessageDTO> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <AddMessageDTO>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = AddMessageDTO.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, AddMessageDTO> mapFromJson(dynamic json) {
    final map = <String, AddMessageDTO>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = AddMessageDTO.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of AddMessageDTO-objects as value to a dart map
  static Map<String, List<AddMessageDTO>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<AddMessageDTO>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = AddMessageDTO.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{};
}
