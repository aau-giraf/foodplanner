//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class PackedIngredient {
  /// Returns a new [PackedIngredient] instance.
  PackedIngredient({
    this.id,
    this.ingredientId,
    this.mealId,
    this.orderNumber,
  });

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? id;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? ingredientId;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? mealId;

  ///
  /// Please note: This property should have been non-nullable! Since the specification file
  /// does not include a default value (using the "default:" property), however, the generated
  /// source code must fall back to having a nullable type.
  /// Consider adding a "default:" property in the specification file to hide this note.
  ///
  int? orderNumber;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PackedIngredient &&
          other.id == id &&
          other.ingredientId == ingredientId &&
          other.mealId == mealId &&
          other.orderNumber == orderNumber;

  @override
  int get hashCode =>
      // ignore: unnecessary_parenthesis
      (id == null ? 0 : id!.hashCode) +
      (ingredientId == null ? 0 : ingredientId!.hashCode) +
      (mealId == null ? 0 : mealId!.hashCode) +
      (orderNumber == null ? 0 : orderNumber!.hashCode);

  @override
  String toString() =>
      'PackedIngredient[id=$id, ingredientId=$ingredientId, mealId=$mealId, orderNumber=$orderNumber]';

  Map<String, dynamic> toJson() {
    final json = <String, dynamic>{};
    if (this.id != null) {
      json[r'id'] = this.id;
    } else {
      json[r'id'] = null;
    }
    if (this.ingredientId != null) {
      json[r'ingredient_id'] = this.ingredientId;
    } else {
      json[r'ingredient_id'] = null;
    }
    if (this.mealId != null) {
      json[r'meal_id'] = this.mealId;
    } else {
      json[r'meal_id'] = null;
    }
    if (this.orderNumber != null) {
      json[r'order_number'] = this.orderNumber;
    } else {
      json[r'order_number'] = null;
    }
    return json;
  }

  /// Returns a new [PackedIngredient] instance and imports its values from
  /// [value] if it's a [Map], null otherwise.
  // ignore: prefer_constructors_over_static_methods
  static PackedIngredient? fromJson(dynamic value) {
    if (value is Map) {
      final json = value.cast<String, dynamic>();

      // Ensure that the map contains the required keys.
      // Note 1: the values aren't checked for validity beyond being non-null.
      // Note 2: this code is stripped in release mode!
      assert(() {
        requiredKeys.forEach((key) {
          assert(json.containsKey(key),
              'Required key "PackedIngredient[$key]" is missing from JSON.');
          assert(json[key] != null,
              'Required key "PackedIngredient[$key]" has a null value in JSON.');
        });
        return true;
      }());

      return PackedIngredient(
        id: mapValueOfType<int>(json, r'id'),
        ingredientId: mapValueOfType<int>(json, r'ingredient_id'),
        mealId: mapValueOfType<int>(json, r'meal_id'),
        orderNumber: mapValueOfType<int>(json, r'order_number'),
      );
    }
    return null;
  }

  static List<PackedIngredient> listFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final result = <PackedIngredient>[];
    if (json is List && json.isNotEmpty) {
      for (final row in json) {
        final value = PackedIngredient.fromJson(row);
        if (value != null) {
          result.add(value);
        }
      }
    }
    return result.toList(growable: growable);
  }

  static Map<String, PackedIngredient> mapFromJson(dynamic json) {
    final map = <String, PackedIngredient>{};
    if (json is Map && json.isNotEmpty) {
      json = json.cast<String, dynamic>(); // ignore: parameter_assignments
      for (final entry in json.entries) {
        final value = PackedIngredient.fromJson(entry.value);
        if (value != null) {
          map[entry.key] = value;
        }
      }
    }
    return map;
  }

  // maps a json object with a list of PackedIngredient-objects as value to a dart map
  static Map<String, List<PackedIngredient>> mapListFromJson(
    dynamic json, {
    bool growable = false,
  }) {
    final map = <String, List<PackedIngredient>>{};
    if (json is Map && json.isNotEmpty) {
      // ignore: parameter_assignments
      json = json.cast<String, dynamic>();
      for (final entry in json.entries) {
        map[entry.key] = PackedIngredient.listFromJson(
          entry.value,
          growable: growable,
        );
      }
    }
    return map;
  }

  /// The list of required keys that must be present in a JSON.
  static const requiredKeys = <String>{};
}
