//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

library openapi.api;

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:collection/collection.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'package:meta/meta.dart';

part 'api_client.dart';
part 'api_helper.dart';
part 'api_exception.dart';
part 'auth/authentication.dart';
part 'auth/api_key_auth.dart';
part 'auth/oauth.dart';
part 'auth/http_basic_auth.dart';
part 'auth/http_bearer_auth.dart';

part 'api/admin_api.dart';
part 'api/childrens_api.dart';
part 'api/classrooms_api.dart';
part 'api/feedback_chat_api.dart';
part 'api/foodplanner_api_api.dart';
part 'api/images_api.dart';
part 'api/ingredients_api.dart';
part 'api/meals_api.dart';
part 'api/packed_ingredient_api.dart';
part 'api/users_api.dart';

part 'model/add_message_dto.dart';
part 'model/children.dart';
part 'model/children_create_dto.dart';
part 'model/children_get_all_dto.dart';
part 'model/create_classroom_dto.dart';
part 'model/food_image.dart';
part 'model/ingredient.dart';
part 'model/ingredient_dto.dart';
part 'model/login.dart';
part 'model/meal.dart';
part 'model/meal_create_dto.dart';
part 'model/packed_ingredient.dart';
part 'model/packed_ingredient_proper_dto.dart';
part 'model/password.dart';
part 'model/pincode.dart';
part 'model/update_message_dto.dart';
part 'model/user.dart';
part 'model/user_create_dto.dart';
part 'model/user_dto.dart';
part 'model/user_role_dto.dart';
part 'model/user_update_dto.dart';

/// An [ApiClient] instance that uses the default values obtained from
/// the OpenAPI specification file.
var defaultApiClient = ApiClient();

const _delimiters = {'csv': ',', 'ssv': ' ', 'tsv': '\t', 'pipes': '|'};
const _dateEpochMarker = 'epoch';
const _deepEquality = DeepCollectionEquality();
final _dateFormatter = DateFormat('yyyy-MM-dd');
final _regList = RegExp(r'^List<(.*)>$');
final _regSet = RegExp(r'^Set<(.*)>$');
final _regMap = RegExp(r'^Map<String,(.*)>$');

bool _isEpochMarker(String? pattern) =>
    pattern == _dateEpochMarker || pattern == '/$_dateEpochMarker/';
