//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class ChildrensApi {
  ChildrensApi([ApiClient? apiClient])
      : apiClient = apiClient ?? defaultApiClient;

  final ApiClient apiClient;

  /// Performs an HTTP 'POST /api/Childrens/Create' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [ChildrenCreateDTO] childrenCreateDTO:
  Future<Response> apiChildrensCreatePostWithHttpInfo({
    String? authorization,
    ChildrenCreateDTO? childrenCreateDTO,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Childrens/Create';

    // ignore: prefer_final_locals
    Object? postBody = childrenCreateDTO;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'POST',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [ChildrenCreateDTO] childrenCreateDTO:
  Future<void> apiChildrensCreatePost({
    String? authorization,
    ChildrenCreateDTO? childrenCreateDTO,
  }) async {
    final response = await apiChildrensCreatePostWithHttpInfo(
      authorization: authorization,
      childrenCreateDTO: childrenCreateDTO,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'DELETE /api/Childrens/Delete/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  Future<Response> apiChildrensDeleteIdDeleteWithHttpInfo(
    int id,
  ) async {
    // ignore: prefer_const_declarations
    final path =
        r'/api/Childrens/Delete/{id}'.replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'DELETE',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  Future<void> apiChildrensDeleteIdDelete(
    int id,
  ) async {
    final response = await apiChildrensDeleteIdDeleteWithHttpInfo(
      id,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/Childrens/GetAllChildrenClasses' operation and returns the [Response].
  Future<Response> apiChildrensGetAllChildrenClassesGetWithHttpInfo() async {
    // ignore: prefer_const_declarations
    final path = r'/api/Childrens/GetAllChildrenClasses';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  Future<List<ChildrenGetAllDTO>?>
      apiChildrensGetAllChildrenClassesGet() async {
    final response = await apiChildrensGetAllChildrenClassesGetWithHttpInfo();
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
    // When a remote server returns no body with a status of 204, we shall not decode it.
    // At the time of writing this, `dart:convert` will throw an "Unexpected end of input"
    // FormatException when trying to decode an empty string.
    if (response.body.isNotEmpty &&
        response.statusCode != HttpStatus.noContent) {
      final responseBody = await _decodeBodyBytes(response);
      return (await apiClient.deserializeAsync(
              responseBody, 'List<ChildrenGetAllDTO>') as List)
          .cast<ChildrenGetAllDTO>()
          .toList(growable: false);
    }
    return null;
  }

  /// Performs an HTTP 'GET /api/Childrens/GetAll' operation and returns the [Response].
  Future<Response> apiChildrensGetAllGetWithHttpInfo() async {
    // ignore: prefer_const_declarations
    final path = r'/api/Childrens/GetAll';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  Future<List<Children>?> apiChildrensGetAllGet() async {
    final response = await apiChildrensGetAllGetWithHttpInfo();
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
    // When a remote server returns no body with a status of 204, we shall not decode it.
    // At the time of writing this, `dart:convert` will throw an "Unexpected end of input"
    // FormatException when trying to decode an empty string.
    if (response.body.isNotEmpty &&
        response.statusCode != HttpStatus.noContent) {
      final responseBody = await _decodeBodyBytes(response);
      return (await apiClient.deserializeAsync(responseBody, 'List<Children>')
              as List)
          .cast<Children>()
          .toList(growable: false);
    }
    return null;
  }

  /// Performs an HTTP 'GET /api/Childrens/GetChildFromChildId/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  Future<Response> apiChildrensGetChildFromChildIdIdGetWithHttpInfo(
    int id,
  ) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Childrens/GetChildFromChildId/{id}'
        .replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  Future<void> apiChildrensGetChildFromChildIdIdGet(
    int id,
  ) async {
    final response = await apiChildrensGetChildFromChildIdIdGetWithHttpInfo(
      id,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/Childrens/GetChildrenByParentId' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  Future<Response> apiChildrensGetChildrenByParentIdGetWithHttpInfo({
    String? authorization,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Childrens/GetChildrenByParentId';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  Future<void> apiChildrensGetChildrenByParentIdGet({
    String? authorization,
  }) async {
    final response = await apiChildrensGetChildrenByParentIdGetWithHttpInfo(
      authorization: authorization,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }
}
