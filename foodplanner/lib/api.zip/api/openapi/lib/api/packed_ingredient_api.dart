//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class PackedIngredientApi {
  PackedIngredientApi([ApiClient? apiClient])
      : apiClient = apiClient ?? defaultApiClient;

  final ApiClient apiClient;

  /// Performs an HTTP 'POST /api/PackedIngredient/Create' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [PackedIngredientProperDTO] packedIngredientProperDTO:
  Future<Response> apiPackedIngredientCreatePostWithHttpInfo({
    PackedIngredientProperDTO? packedIngredientProperDTO,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/PackedIngredient/Create';

    // ignore: prefer_final_locals
    Object? postBody = packedIngredientProperDTO;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'POST',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [PackedIngredientProperDTO] packedIngredientProperDTO:
  Future<void> apiPackedIngredientCreatePost({
    PackedIngredientProperDTO? packedIngredientProperDTO,
  }) async {
    final response = await apiPackedIngredientCreatePostWithHttpInfo(
      packedIngredientProperDTO: packedIngredientProperDTO,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'DELETE /api/PackedIngredient/Delete/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  Future<Response> apiPackedIngredientDeleteIdDeleteWithHttpInfo(
    int id,
  ) async {
    // ignore: prefer_const_declarations
    final path =
        r'/api/PackedIngredient/Delete/{id}'.replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'DELETE',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  Future<void> apiPackedIngredientDeleteIdDelete(
    int id,
  ) async {
    final response = await apiPackedIngredientDeleteIdDeleteWithHttpInfo(
      id,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/PackedIngredient/GetAll' operation and returns the [Response].
  Future<Response> apiPackedIngredientGetAllGetWithHttpInfo() async {
    // ignore: prefer_const_declarations
    final path = r'/api/PackedIngredient/GetAll';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  Future<void> apiPackedIngredientGetAllGet() async {
    final response = await apiPackedIngredientGetAllGetWithHttpInfo();
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/PackedIngredient/Get/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  Future<Response> apiPackedIngredientGetIdGetWithHttpInfo(
    int id,
  ) async {
    // ignore: prefer_const_declarations
    final path =
        r'/api/PackedIngredient/Get/{id}'.replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  Future<void> apiPackedIngredientGetIdGet(
    int id,
  ) async {
    final response = await apiPackedIngredientGetIdGetWithHttpInfo(
      id,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'PUT /api/PackedIngredient/Update/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  ///
  /// * [PackedIngredient] packedIngredient:
  Future<Response> apiPackedIngredientUpdateIdPutWithHttpInfo(
    int id, {
    PackedIngredient? packedIngredient,
  }) async {
    // ignore: prefer_const_declarations
    final path =
        r'/api/PackedIngredient/Update/{id}'.replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody = packedIngredient;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'PUT',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  ///
  /// * [PackedIngredient] packedIngredient:
  Future<void> apiPackedIngredientUpdateIdPut(
    int id, {
    PackedIngredient? packedIngredient,
  }) async {
    final response = await apiPackedIngredientUpdateIdPutWithHttpInfo(
      id,
      packedIngredient: packedIngredient,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'PUT /api/PackedIngredient/UpdateOrder' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [List<PackedIngredient>] packedIngredient:
  Future<Response> apiPackedIngredientUpdateOrderPutWithHttpInfo({
    List<PackedIngredient>? packedIngredient,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/PackedIngredient/UpdateOrder';

    // ignore: prefer_final_locals
    Object? postBody = packedIngredient;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'PUT',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [List<PackedIngredient>] packedIngredient:
  Future<void> apiPackedIngredientUpdateOrderPut({
    List<PackedIngredient>? packedIngredient,
  }) async {
    final response = await apiPackedIngredientUpdateOrderPutWithHttpInfo(
      packedIngredient: packedIngredient,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }
}
