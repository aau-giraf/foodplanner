//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class MealsApi {
  MealsApi([ApiClient? apiClient]) : apiClient = apiClient ?? defaultApiClient;

  final ApiClient apiClient;

  /// Performs an HTTP 'POST /api/Meals/Create' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [MealCreateDTO] mealCreateDTO:
  Future<Response> apiMealsCreatePostWithHttpInfo({
    String? authorization,
    MealCreateDTO? mealCreateDTO,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Meals/Create';

    // ignore: prefer_final_locals
    Object? postBody = mealCreateDTO;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'POST',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [MealCreateDTO] mealCreateDTO:
  Future<void> apiMealsCreatePost({
    String? authorization,
    MealCreateDTO? mealCreateDTO,
  }) async {
    final response = await apiMealsCreatePostWithHttpInfo(
      authorization: authorization,
      mealCreateDTO: mealCreateDTO,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'DELETE /api/Meals/Delete/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  Future<Response> apiMealsDeleteIdDeleteWithHttpInfo(
    int id,
  ) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Meals/Delete/{id}'.replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'DELETE',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  Future<void> apiMealsDeleteIdDelete(
    int id,
  ) async {
    final response = await apiMealsDeleteIdDeleteWithHttpInfo(
      id,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/Meals/GetAllByUser/{date}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] date (required):
  ///
  /// * [String] authorization:
  Future<Response> apiMealsGetAllByUserDateGetWithHttpInfo(
    String date, {
    String? authorization,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Meals/GetAllByUser/{date}'.replaceAll('{date}', date);

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] date (required):
  ///
  /// * [String] authorization:
  Future<void> apiMealsGetAllByUserDateGet(
    String date, {
    String? authorization,
  }) async {
    final response = await apiMealsGetAllByUserDateGetWithHttpInfo(
      date,
      authorization: authorization,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/Meals/GetAll' operation and returns the [Response].
  Future<Response> apiMealsGetAllGetWithHttpInfo() async {
    // ignore: prefer_const_declarations
    final path = r'/api/Meals/GetAll';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  Future<void> apiMealsGetAllGet() async {
    final response = await apiMealsGetAllGetWithHttpInfo();
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/Meals/Get/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  Future<Response> apiMealsGetIdGetWithHttpInfo(
    int id,
  ) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Meals/Get/{id}'.replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  Future<void> apiMealsGetIdGet(
    int id,
  ) async {
    final response = await apiMealsGetIdGetWithHttpInfo(
      id,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/Meals/TeacherGetUserMeals' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] date:
  ///
  /// * [int] id:
  Future<Response> apiMealsTeacherGetUserMealsGetWithHttpInfo({
    String? date,
    int? id,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Meals/TeacherGetUserMeals';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (date != null) {
      queryParams.addAll(_queryParams('', 'date', date));
    }
    if (id != null) {
      queryParams.addAll(_queryParams('', 'id', id));
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] date:
  ///
  /// * [int] id:
  Future<void> apiMealsTeacherGetUserMealsGet({
    String? date,
    int? id,
  }) async {
    final response = await apiMealsTeacherGetUserMealsGetWithHttpInfo(
      date: date,
      id: id,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'PUT /api/Meals/Update/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  ///
  /// * [String] authorization:
  ///
  /// * [Meal] meal:
  Future<Response> apiMealsUpdateIdPutWithHttpInfo(
    int id, {
    String? authorization,
    Meal? meal,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Meals/Update/{id}'.replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody = meal;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'PUT',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  ///
  /// * [String] authorization:
  ///
  /// * [Meal] meal:
  Future<void> apiMealsUpdateIdPut(
    int id, {
    String? authorization,
    Meal? meal,
  }) async {
    final response = await apiMealsUpdateIdPutWithHttpInfo(
      id,
      authorization: authorization,
      meal: meal,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }
}
