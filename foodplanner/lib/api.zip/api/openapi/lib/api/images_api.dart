//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class ImagesApi {
  ImagesApi([ApiClient? apiClient]) : apiClient = apiClient ?? defaultApiClient;

  final ApiClient apiClient;

  /// Performs an HTTP 'DELETE /api/Images/DeleteImages' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [List<int>] foodImageIds:
  Future<Response> apiImagesDeleteImagesDeleteWithHttpInfo({
    List<int>? foodImageIds,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Images/DeleteImages';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (foodImageIds != null) {
      queryParams.addAll(_queryParams('multi', 'foodImageIds', foodImageIds));
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'DELETE',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [List<int>] foodImageIds:
  Future<void> apiImagesDeleteImagesDelete({
    List<int>? foodImageIds,
  }) async {
    final response = await apiImagesDeleteImagesDeleteWithHttpInfo(
      foodImageIds: foodImageIds,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/Images/GetFoodImage' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] foodImageId:
  Future<Response> apiImagesGetFoodImageGetWithHttpInfo({
    int? foodImageId,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Images/GetFoodImage';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (foodImageId != null) {
      queryParams.addAll(_queryParams('', 'foodImageId', foodImageId));
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] foodImageId:
  Future<FoodImage?> apiImagesGetFoodImageGet({
    int? foodImageId,
  }) async {
    final response = await apiImagesGetFoodImageGetWithHttpInfo(
      foodImageId: foodImageId,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
    // When a remote server returns no body with a status of 204, we shall not decode it.
    // At the time of writing this, `dart:convert` will throw an "Unexpected end of input"
    // FormatException when trying to decode an empty string.
    if (response.body.isNotEmpty &&
        response.statusCode != HttpStatus.noContent) {
      return await apiClient.deserializeAsync(
        await _decodeBodyBytes(response),
        'FoodImage',
      ) as FoodImage;
    }
    return null;
  }

  /// Performs an HTTP 'GET /api/Images/GetPresignedImageLink' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] foodImageId:
  Future<Response> apiImagesGetPresignedImageLinkGetWithHttpInfo({
    int? foodImageId,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Images/GetPresignedImageLink';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (foodImageId != null) {
      queryParams.addAll(_queryParams('', 'foodImageId', foodImageId));
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] foodImageId:
  Future<String?> apiImagesGetPresignedImageLinkGet({
    int? foodImageId,
  }) async {
    final response = await apiImagesGetPresignedImageLinkGetWithHttpInfo(
      foodImageId: foodImageId,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
    // When a remote server returns no body with a status of 204, we shall not decode it.
    // At the time of writing this, `dart:convert` will throw an "Unexpected end of input"
    // FormatException when trying to decode an empty string.
    if (response.body.isNotEmpty &&
        response.statusCode != HttpStatus.noContent) {
      return await apiClient.deserializeAsync(
        await _decodeBodyBytes(response),
        'String',
      ) as String;
    }
    return null;
  }

  /// Performs an HTTP 'POST /api/Images/UploadImage' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [MultipartFile] imageFile:
  Future<Response> apiImagesUploadImagePostWithHttpInfo({
    String? authorization,
    MultipartFile? imageFile,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Images/UploadImage';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>['multipart/form-data'];

    bool hasFields = false;
    final mp = MultipartRequest('POST', Uri.parse(path));
    if (imageFile != null) {
      hasFields = true;
      mp.fields[r'imageFile'] = imageFile.field;
      mp.files.add(imageFile);
    }
    if (hasFields) {
      postBody = mp;
    }

    return apiClient.invokeAPI(
      path,
      'POST',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [MultipartFile] imageFile:
  Future<void> apiImagesUploadImagePost({
    String? authorization,
    MultipartFile? imageFile,
  }) async {
    final response = await apiImagesUploadImagePostWithHttpInfo(
      authorization: authorization,
      imageFile: imageFile,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }
}
