//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class UsersApi {
  UsersApi([ApiClient? apiClient]) : apiClient = apiClient ?? defaultApiClient;

  final ApiClient apiClient;

  /// Performs an HTTP 'POST /api/Users/CheckPinCode' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [Pincode] pincode:
  Future<Response> apiUsersCheckPinCodePostWithHttpInfo({
    String? authorization,
    Pincode? pincode,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Users/CheckPinCode';

    // ignore: prefer_final_locals
    Object? postBody = pincode;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'POST',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [Pincode] pincode:
  Future<String?> apiUsersCheckPinCodePost({
    String? authorization,
    Pincode? pincode,
  }) async {
    final response = await apiUsersCheckPinCodePostWithHttpInfo(
      authorization: authorization,
      pincode: pincode,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
    // When a remote server returns no body with a status of 204, we shall not decode it.
    // At the time of writing this, `dart:convert` will throw an "Unexpected end of input"
    // FormatException when trying to decode an empty string.
    if (response.body.isNotEmpty &&
        response.statusCode != HttpStatus.noContent) {
      return await apiClient.deserializeAsync(
        await _decodeBodyBytes(response),
        'String',
      ) as String;
    }
    return null;
  }

  /// Performs an HTTP 'POST /api/Users/Create' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [UserCreateDTO] userCreateDTO:
  Future<Response> apiUsersCreatePostWithHttpInfo({
    UserCreateDTO? userCreateDTO,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Users/Create';

    // ignore: prefer_final_locals
    Object? postBody = userCreateDTO;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'POST',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [UserCreateDTO] userCreateDTO:
  Future<String?> apiUsersCreatePost({
    UserCreateDTO? userCreateDTO,
  }) async {
    final response = await apiUsersCreatePostWithHttpInfo(
      userCreateDTO: userCreateDTO,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
    // When a remote server returns no body with a status of 204, we shall not decode it.
    // At the time of writing this, `dart:convert` will throw an "Unexpected end of input"
    // FormatException when trying to decode an empty string.
    if (response.body.isNotEmpty &&
        response.statusCode != HttpStatus.noContent) {
      return await apiClient.deserializeAsync(
        await _decodeBodyBytes(response),
        'String',
      ) as String;
    }
    return null;
  }

  /// Performs an HTTP 'GET /api/Users/GetBearerTest' operation and returns the [Response].
  Future<Response> apiUsersGetBearerTestGetWithHttpInfo() async {
    // ignore: prefer_const_declarations
    final path = r'/api/Users/GetBearerTest';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  Future<String?> apiUsersGetBearerTestGet() async {
    final response = await apiUsersGetBearerTestGetWithHttpInfo();
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
    // When a remote server returns no body with a status of 204, we shall not decode it.
    // At the time of writing this, `dart:convert` will throw an "Unexpected end of input"
    // FormatException when trying to decode an empty string.
    if (response.body.isNotEmpty &&
        response.statusCode != HttpStatus.noContent) {
      return await apiClient.deserializeAsync(
        await _decodeBodyBytes(response),
        'String',
      ) as String;
    }
    return null;
  }

  /// Performs an HTTP 'GET /api/Users/GetLoggedIn' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  Future<Response> apiUsersGetLoggedInGetWithHttpInfo({
    String? authorization,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Users/GetLoggedIn';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  Future<void> apiUsersGetLoggedInGet({
    String? authorization,
  }) async {
    final response = await apiUsersGetLoggedInGetWithHttpInfo(
      authorization: authorization,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/Users/HasPinCode' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  Future<Response> apiUsersHasPinCodeGetWithHttpInfo({
    String? authorization,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Users/HasPinCode';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  Future<void> apiUsersHasPinCodeGet({
    String? authorization,
  }) async {
    final response = await apiUsersHasPinCodeGetWithHttpInfo(
      authorization: authorization,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'POST /api/Users/Login' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [Login] login:
  Future<Response> apiUsersLoginPostWithHttpInfo({
    Login? login,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Users/Login';

    // ignore: prefer_final_locals
    Object? postBody = login;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'POST',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [Login] login:
  Future<String?> apiUsersLoginPost({
    Login? login,
  }) async {
    final response = await apiUsersLoginPostWithHttpInfo(
      login: login,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
    // When a remote server returns no body with a status of 204, we shall not decode it.
    // At the time of writing this, `dart:convert` will throw an "Unexpected end of input"
    // FormatException when trying to decode an empty string.
    if (response.body.isNotEmpty &&
        response.statusCode != HttpStatus.noContent) {
      return await apiClient.deserializeAsync(
        await _decodeBodyBytes(response),
        'String',
      ) as String;
    }
    return null;
  }

  /// Performs an HTTP 'PUT /api/Users/UpdateLoggedIn' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [UserUpdateDTO] userUpdateDTO:
  Future<Response> apiUsersUpdateLoggedInPutWithHttpInfo({
    String? authorization,
    UserUpdateDTO? userUpdateDTO,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Users/UpdateLoggedIn';

    // ignore: prefer_final_locals
    Object? postBody = userUpdateDTO;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'PUT',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [UserUpdateDTO] userUpdateDTO:
  Future<void> apiUsersUpdateLoggedInPut({
    String? authorization,
    UserUpdateDTO? userUpdateDTO,
  }) async {
    final response = await apiUsersUpdateLoggedInPutWithHttpInfo(
      authorization: authorization,
      userUpdateDTO: userUpdateDTO,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'PUT /api/Users/UpdatePassword' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [Password] password:
  Future<Response> apiUsersUpdatePasswordPutWithHttpInfo({
    String? authorization,
    Password? password,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Users/UpdatePassword';

    // ignore: prefer_final_locals
    Object? postBody = password;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'PUT',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [Password] password:
  Future<void> apiUsersUpdatePasswordPut({
    String? authorization,
    Password? password,
  }) async {
    final response = await apiUsersUpdatePasswordPutWithHttpInfo(
      authorization: authorization,
      password: password,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'PUT /api/Users/UpdatePinCode' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [Pincode] pincode:
  Future<Response> apiUsersUpdatePinCodePutWithHttpInfo({
    String? authorization,
    Pincode? pincode,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Users/UpdatePinCode';

    // ignore: prefer_final_locals
    Object? postBody = pincode;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'PUT',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [Pincode] pincode:
  Future<void> apiUsersUpdatePinCodePut({
    String? authorization,
    Pincode? pincode,
  }) async {
    final response = await apiUsersUpdatePinCodePutWithHttpInfo(
      authorization: authorization,
      pincode: pincode,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }
}
