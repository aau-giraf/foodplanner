//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class ClassroomsApi {
  ClassroomsApi([ApiClient? apiClient])
      : apiClient = apiClient ?? defaultApiClient;

  final ApiClient apiClient;

  /// Performs an HTTP 'POST /api/Classrooms/Create' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [CreateClassroomDTO] createClassroomDTO:
  Future<Response> apiClassroomsCreatePostWithHttpInfo({
    CreateClassroomDTO? createClassroomDTO,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/Classrooms/Create';

    // ignore: prefer_final_locals
    Object? postBody = createClassroomDTO;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'POST',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [CreateClassroomDTO] createClassroomDTO:
  Future<void> apiClassroomsCreatePost({
    CreateClassroomDTO? createClassroomDTO,
  }) async {
    final response = await apiClassroomsCreatePostWithHttpInfo(
      createClassroomDTO: createClassroomDTO,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'DELETE /api/Classrooms/Delete/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  Future<Response> apiClassroomsDeleteIdDeleteWithHttpInfo(
    int id,
  ) async {
    // ignore: prefer_const_declarations
    final path =
        r'/api/Classrooms/Delete/{id}'.replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'DELETE',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  Future<void> apiClassroomsDeleteIdDelete(
    int id,
  ) async {
    final response = await apiClassroomsDeleteIdDeleteWithHttpInfo(
      id,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/Classrooms/GetAll' operation and returns the [Response].
  Future<Response> apiClassroomsGetAllGetWithHttpInfo() async {
    // ignore: prefer_const_declarations
    final path = r'/api/Classrooms/GetAll';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  Future<void> apiClassroomsGetAllGet() async {
    final response = await apiClassroomsGetAllGetWithHttpInfo();
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'PUT /api/Classrooms/Update/{id}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] id (required):
  ///
  /// * [CreateClassroomDTO] createClassroomDTO:
  Future<Response> apiClassroomsUpdateIdPutWithHttpInfo(
    int id, {
    CreateClassroomDTO? createClassroomDTO,
  }) async {
    // ignore: prefer_const_declarations
    final path =
        r'/api/Classrooms/Update/{id}'.replaceAll('{id}', id.toString());

    // ignore: prefer_final_locals
    Object? postBody = createClassroomDTO;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'PUT',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] id (required):
  ///
  /// * [CreateClassroomDTO] createClassroomDTO:
  Future<void> apiClassroomsUpdateIdPut(
    int id, {
    CreateClassroomDTO? createClassroomDTO,
  }) async {
    final response = await apiClassroomsUpdateIdPutWithHttpInfo(
      id,
      createClassroomDTO: createClassroomDTO,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }
}
