//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

part of openapi.api;

class FeedbackChatApi {
  FeedbackChatApi([ApiClient? apiClient])
      : apiClient = apiClient ?? defaultApiClient;

  final ApiClient apiClient;

  /// Performs an HTTP 'POST /api/FeedbackChat/AddMessage' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [AddMessageDTO] addMessageDTO:
  Future<Response> apiFeedbackChatAddMessagePostWithHttpInfo({
    String? authorization,
    AddMessageDTO? addMessageDTO,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/FeedbackChat/AddMessage';

    // ignore: prefer_final_locals
    Object? postBody = addMessageDTO;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'POST',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  ///
  /// * [AddMessageDTO] addMessageDTO:
  Future<void> apiFeedbackChatAddMessagePost({
    String? authorization,
    AddMessageDTO? addMessageDTO,
  }) async {
    final response = await apiFeedbackChatAddMessagePostWithHttpInfo(
      authorization: authorization,
      addMessageDTO: addMessageDTO,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'DELETE /api/FeedbackChat/ArchiveMessage/{messageId}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] messageId (required):
  Future<Response> apiFeedbackChatArchiveMessageMessageIdDeleteWithHttpInfo(
    int messageId,
  ) async {
    // ignore: prefer_const_declarations
    final path = r'/api/FeedbackChat/ArchiveMessage/{messageId}'
        .replaceAll('{messageId}', messageId.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'DELETE',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] messageId (required):
  Future<void> apiFeedbackChatArchiveMessageMessageIdDelete(
    int messageId,
  ) async {
    final response =
        await apiFeedbackChatArchiveMessageMessageIdDeleteWithHttpInfo(
      messageId,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/FeedbackChat/GetChatThreadIdAndUserIdFromChildIdAndToken/{childId}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] childId (required):
  ///
  /// * [String] authorization:
  Future<Response>
      apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGetWithHttpInfo(
    int childId, {
    String? authorization,
  }) async {
    // ignore: prefer_const_declarations
    final path =
        r'/api/FeedbackChat/GetChatThreadIdAndUserIdFromChildIdAndToken/{childId}'
            .replaceAll('{childId}', childId.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] childId (required):
  ///
  /// * [String] authorization:
  Future<void>
      apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGet(
    int childId, {
    String? authorization,
  }) async {
    final response =
        await apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGetWithHttpInfo(
      childId,
      authorization: authorization,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/FeedbackChat/GetChatThreadIdAndUserIdFromToken' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [String] authorization:
  Future<Response>
      apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGetWithHttpInfo({
    String? authorization,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/FeedbackChat/GetChatThreadIdAndUserIdFromToken';

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    if (authorization != null) {
      headerParams[r'Authorization'] = parameterToString(authorization);
    }

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [String] authorization:
  Future<void> apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGet({
    String? authorization,
  }) async {
    final response =
        await apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGetWithHttpInfo(
      authorization: authorization,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'GET /api/FeedbackChat/GetMessages/{chatThreadId}' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [int] chatThreadId (required):
  Future<Response> apiFeedbackChatGetMessagesChatThreadIdGetWithHttpInfo(
    int chatThreadId,
  ) async {
    // ignore: prefer_const_declarations
    final path = r'/api/FeedbackChat/GetMessages/{chatThreadId}'
        .replaceAll('{chatThreadId}', chatThreadId.toString());

    // ignore: prefer_final_locals
    Object? postBody;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[];

    return apiClient.invokeAPI(
      path,
      'GET',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [int] chatThreadId (required):
  Future<void> apiFeedbackChatGetMessagesChatThreadIdGet(
    int chatThreadId,
  ) async {
    final response =
        await apiFeedbackChatGetMessagesChatThreadIdGetWithHttpInfo(
      chatThreadId,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }

  /// Performs an HTTP 'PUT /api/FeedbackChat/UpdateMessage' operation and returns the [Response].
  /// Parameters:
  ///
  /// * [UpdateMessageDTO] updateMessageDTO:
  Future<Response> apiFeedbackChatUpdateMessagePutWithHttpInfo({
    UpdateMessageDTO? updateMessageDTO,
  }) async {
    // ignore: prefer_const_declarations
    final path = r'/api/FeedbackChat/UpdateMessage';

    // ignore: prefer_final_locals
    Object? postBody = updateMessageDTO;

    final queryParams = <QueryParam>[];
    final headerParams = <String, String>{};
    final formParams = <String, String>{};

    const contentTypes = <String>[
      'application/json',
      'text/json',
      'application/*+json'
    ];

    return apiClient.invokeAPI(
      path,
      'PUT',
      queryParams,
      postBody,
      headerParams,
      formParams,
      contentTypes.isEmpty ? null : contentTypes.first,
    );
  }

  /// Parameters:
  ///
  /// * [UpdateMessageDTO] updateMessageDTO:
  Future<void> apiFeedbackChatUpdateMessagePut({
    UpdateMessageDTO? updateMessageDTO,
  }) async {
    final response = await apiFeedbackChatUpdateMessagePutWithHttpInfo(
      updateMessageDTO: updateMessageDTO,
    );
    if (response.statusCode >= HttpStatus.badRequest) {
      throw ApiException(response.statusCode, await _decodeBodyBytes(response));
    }
  }
}
