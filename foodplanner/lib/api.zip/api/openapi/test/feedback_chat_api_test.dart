//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

/// tests for FeedbackChatApi
void main() {
  // final instance = FeedbackChatApi();

  group('tests for FeedbackChatApi', () {
    //Future apiFeedbackChatAddMessagePost({ String authorization, AddMessageDTO addMessageDTO }) async
    test('test apiFeedbackChatAddMessagePost', () async {
      // TODO
    });

    //Future apiFeedbackChatArchiveMessageMessageIdDelete(int messageId) async
    test('test apiFeedbackChatArchiveMessageMessageIdDelete', () async {
      // TODO
    });

    //Future apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGet(int childId, { String authorization }) async
    test(
        'test apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGet',
        () async {
      // TODO
    });

    //Future apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGet({ String authorization }) async
    test('test apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGet', () async {
      // TODO
    });

    //Future apiFeedbackChatGetMessagesChatThreadIdGet(int chatThreadId) async
    test('test apiFeedbackChatGetMessagesChatThreadIdGet', () async {
      // TODO
    });

    //Future apiFeedbackChatUpdateMessagePut({ UpdateMessageDTO updateMessageDTO }) async
    test('test apiFeedbackChatUpdateMessagePut', () async {
      // TODO
    });
  });
}
