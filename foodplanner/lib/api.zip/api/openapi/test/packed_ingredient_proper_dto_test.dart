//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

// tests for PackedIngredientProperDTO
void main() {
  // final instance = PackedIngredientProperDTO();

  group('test PackedIngredientProperDTO', () {
    // int mealId
    test('to test the property `mealId`', () async {
      // TODO
    });

    // int ingredientId
    test('to test the property `ingredientId`', () async {
      // TODO
    });
  });
}
