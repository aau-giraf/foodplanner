//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

// tests for FoodImage
void main() {
  // final instance = FoodImage();

  group('test FoodImage', () {
    // String imageId
    test('to test the property `imageId`', () async {
      // TODO
    });

    // int userId
    test('to test the property `userId`', () async {
      // TODO
    });

    // String imageName
    test('to test the property `imageName`', () async {
      // TODO
    });

    // String imageFileType
    test('to test the property `imageFileType`', () async {
      // TODO
    });

    // int size
    test('to test the property `size`', () async {
      // TODO
    });
  });
}
