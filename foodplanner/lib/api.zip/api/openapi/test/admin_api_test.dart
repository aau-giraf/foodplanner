//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

/// tests for AdminApi
void main() {
  // final instance = AdminApi();

  group('tests for AdminApi', () {
    //Future apiAdminDeleteIdDelete(int id) async
    test('test apiAdminDeleteIdDelete', () async {
      // TODO
    });

    //Future apiAdminGetAllChildrenGet() async
    test('test apiAdminGetAllChildrenGet', () async {
      // TODO
    });

    //Future<List<UserDTO>> apiAdminGetAllGet() async
    test('test apiAdminGetAllGet', () async {
      // TODO
    });

    //Future<List<UserDTO>> apiAdminGetIdGet(int id) async
    test('test apiAdminGetIdGet', () async {
      // TODO
    });

    //Future apiAdminGetNotApprovedGet() async
    test('test apiAdminGetNotApprovedGet', () async {
      // TODO
    });

    //Future apiAdminGetNotArchivedGet() async
    test('test apiAdminGetNotArchivedGet', () async {
      // TODO
    });

    //Future apiAdminUpdateArchivedIdPut(int id) async
    test('test apiAdminUpdateArchivedIdPut', () async {
      // TODO
    });

    //Future apiAdminUpdateChildPut({ Children children }) async
    test('test apiAdminUpdateChildPut', () async {
      // TODO
    });

    //Future apiAdminUpdateIdPut(int id, { User user }) async
    test('test apiAdminUpdateIdPut', () async {
      // TODO
    });

    //Future apiAdminUpdateRoleApprovedIdPut(int id, { UserRoleDTO userRoleDTO }) async
    test('test apiAdminUpdateRoleApprovedIdPut', () async {
      // TODO
    });
  });
}
