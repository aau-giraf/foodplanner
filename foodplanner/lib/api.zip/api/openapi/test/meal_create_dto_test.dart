//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

// tests for MealCreateDTO
void main() {
  // final instance = MealCreateDTO();

  group('test MealCreateDTO', () {
    // int foodImageId
    test('to test the property `foodImageId`', () async {
      // TODO
    });

    // String name
    test('to test the property `name`', () async {
      // TODO
    });

    // String date
    test('to test the property `date`', () async {
      // TODO
    });
  });
}
