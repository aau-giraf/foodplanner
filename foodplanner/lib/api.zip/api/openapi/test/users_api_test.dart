//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

/// tests for UsersApi
void main() {
  // final instance = UsersApi();

  group('tests for UsersApi', () {
    //Future<String> apiUsersCheckPinCodePost({ String authorization, Pincode pincode }) async
    test('test apiUsersCheckPinCodePost', () async {
      // TODO
    });

    //Future<String> apiUsersCreatePost({ UserCreateDTO userCreateDTO }) async
    test('test apiUsersCreatePost', () async {
      // TODO
    });

    //Future<String> apiUsersGetBearerTestGet() async
    test('test apiUsersGetBearerTestGet', () async {
      // TODO
    });

    //Future apiUsersGetLoggedInGet({ String authorization }) async
    test('test apiUsersGetLoggedInGet', () async {
      // TODO
    });

    //Future apiUsersHasPinCodeGet({ String authorization }) async
    test('test apiUsersHasPinCodeGet', () async {
      // TODO
    });

    //Future<String> apiUsersLoginPost({ Login login }) async
    test('test apiUsersLoginPost', () async {
      // TODO
    });

    //Future apiUsersUpdateLoggedInPut({ String authorization, UserUpdateDTO userUpdateDTO }) async
    test('test apiUsersUpdateLoggedInPut', () async {
      // TODO
    });

    //Future apiUsersUpdatePasswordPut({ String authorization, Password password }) async
    test('test apiUsersUpdatePasswordPut', () async {
      // TODO
    });

    //Future apiUsersUpdatePinCodePut({ String authorization, Pincode pincode }) async
    test('test apiUsersUpdatePinCodePut', () async {
      // TODO
    });
  });
}
