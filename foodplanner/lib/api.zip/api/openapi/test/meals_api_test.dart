//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

/// tests for MealsApi
void main() {
  // final instance = MealsApi();

  group('tests for MealsApi', () {
    //Future apiMealsCreatePost({ String authorization, MealCreateDTO mealCreateDTO }) async
    test('test apiMealsCreatePost', () async {
      // TODO
    });

    //Future apiMealsDeleteIdDelete(int id) async
    test('test apiMealsDeleteIdDelete', () async {
      // TODO
    });

    //Future apiMealsGetAllByUserDateGet(String date, { String authorization }) async
    test('test apiMealsGetAllByUserDateGet', () async {
      // TODO
    });

    //Future apiMealsGetAllGet() async
    test('test apiMealsGetAllGet', () async {
      // TODO
    });

    //Future apiMealsGetIdGet(int id) async
    test('test apiMealsGetIdGet', () async {
      // TODO
    });

    //Future apiMealsTeacherGetUserMealsGet({ String date, int id }) async
    test('test apiMealsTeacherGetUserMealsGet', () async {
      // TODO
    });

    //Future apiMealsUpdateIdPut(int id, { String authorization, Meal meal }) async
    test('test apiMealsUpdateIdPut', () async {
      // TODO
    });
  });
}
