//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

/// tests for IngredientsApi
void main() {
  // final instance = IngredientsApi();

  group('tests for IngredientsApi', () {
    //Future apiIngredientsCreatePost({ String authorization, IngredientDTO ingredientDTO }) async
    test('test apiIngredientsCreatePost', () async {
      // TODO
    });

    //Future apiIngredientsDeleteIdDelete(int id) async
    test('test apiIngredientsDeleteIdDelete', () async {
      // TODO
    });

    //Future apiIngredientsGetAllByUserGet({ String authorization }) async
    test('test apiIngredientsGetAllByUserGet', () async {
      // TODO
    });

    //Future apiIngredientsGetAllGet() async
    test('test apiIngredientsGetAllGet', () async {
      // TODO
    });

    //Future apiIngredientsGetIdGet(int id) async
    test('test apiIngredientsGetIdGet', () async {
      // TODO
    });

    //Future apiIngredientsUpdateIdPut(int id, { Ingredient ingredient }) async
    test('test apiIngredientsUpdateIdPut', () async {
      // TODO
    });
  });
}
