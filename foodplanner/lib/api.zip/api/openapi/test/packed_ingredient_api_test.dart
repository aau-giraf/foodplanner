//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

/// tests for PackedIngredientApi
void main() {
  // final instance = PackedIngredientApi();

  group('tests for PackedIngredientApi', () {
    //Future apiPackedIngredientCreatePost({ PackedIngredientProperDTO packedIngredientProperDTO }) async
    test('test apiPackedIngredientCreatePost', () async {
      // TODO
    });

    //Future apiPackedIngredientDeleteIdDelete(int id) async
    test('test apiPackedIngredientDeleteIdDelete', () async {
      // TODO
    });

    //Future apiPackedIngredientGetAllGet() async
    test('test apiPackedIngredientGetAllGet', () async {
      // TODO
    });

    //Future apiPackedIngredientGetIdGet(int id) async
    test('test apiPackedIngredientGetIdGet', () async {
      // TODO
    });

    //Future apiPackedIngredientUpdateIdPut(int id, { PackedIngredient packedIngredient }) async
    test('test apiPackedIngredientUpdateIdPut', () async {
      // TODO
    });

    //Future apiPackedIngredientUpdateOrderPut({ List<PackedIngredient> packedIngredient }) async
    test('test apiPackedIngredientUpdateOrderPut', () async {
      // TODO
    });
  });
}
