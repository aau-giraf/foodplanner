//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

/// tests for ClassroomsApi
void main() {
  // final instance = ClassroomsApi();

  group('tests for ClassroomsApi', () {
    //Future apiClassroomsCreatePost({ CreateClassroomDTO createClassroomDTO }) async
    test('test apiClassroomsCreatePost', () async {
      // TODO
    });

    //Future apiClassroomsDeleteIdDelete(int id) async
    test('test apiClassroomsDeleteIdDelete', () async {
      // TODO
    });

    //Future apiClassroomsGetAllGet() async
    test('test apiClassroomsGetAllGet', () async {
      // TODO
    });

    //Future apiClassroomsUpdateIdPut(int id, { CreateClassroomDTO createClassroomDTO }) async
    test('test apiClassroomsUpdateIdPut', () async {
      // TODO
    });
  });
}
