//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

// tests for Children
void main() {
  // final instance = Children();

  group('test Children', () {
    // String firstName
    test('to test the property `firstName`', () async {
      // TODO
    });

    // String lastName
    test('to test the property `lastName`', () async {
      // TODO
    });

    // int childId
    test('to test the property `childId`', () async {
      // TODO
    });

    // int parentId
    test('to test the property `parentId`', () async {
      // TODO
    });

    // int classId
    test('to test the property `classId`', () async {
      // TODO
    });
  });
}
