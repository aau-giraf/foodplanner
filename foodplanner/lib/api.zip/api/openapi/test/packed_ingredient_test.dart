//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

// tests for PackedIngredient
void main() {
  // final instance = PackedIngredient();

  group('test PackedIngredient', () {
    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // int ingredientId
    test('to test the property `ingredientId`', () async {
      // TODO
    });

    // int mealId
    test('to test the property `mealId`', () async {
      // TODO
    });

    // int orderNumber
    test('to test the property `orderNumber`', () async {
      // TODO
    });
  });
}
