//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

/// tests for ImagesApi
void main() {
  // final instance = ImagesApi();

  group('tests for ImagesApi', () {
    //Future apiImagesDeleteImagesDelete({ List<int> foodImageIds }) async
    test('test apiImagesDeleteImagesDelete', () async {
      // TODO
    });

    //Future<FoodImage> apiImagesGetFoodImageGet({ int foodImageId }) async
    test('test apiImagesGetFoodImageGet', () async {
      // TODO
    });

    //Future<String> apiImagesGetPresignedImageLinkGet({ int foodImageId }) async
    test('test apiImagesGetPresignedImageLinkGet', () async {
      // TODO
    });

    //Future apiImagesUploadImagePost({ String authorization, MultipartFile imageFile }) async
    test('test apiImagesUploadImagePost', () async {
      // TODO
    });
  });
}
