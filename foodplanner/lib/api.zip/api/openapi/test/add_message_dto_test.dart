//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

// tests for AddMessageDTO
void main() {
  // final instance = AddMessageDTO();

  group('test AddMessageDTO', () {
    // int chatThreadId
    test('to test the property `chatThreadId`', () async {
      // TODO
    });

    // String content
    test('to test the property `content`', () async {
      // TODO
    });
  });
}
