//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

/// tests for ChildrensApi
void main() {
  // final instance = ChildrensApi();

  group('tests for ChildrensApi', () {
    //Future apiChildrensCreatePost({ String authorization, ChildrenCreateDTO childrenCreateDTO }) async
    test('test apiChildrensCreatePost', () async {
      // TODO
    });

    //Future apiChildrensDeleteIdDelete(int id) async
    test('test apiChildrensDeleteIdDelete', () async {
      // TODO
    });

    //Future<List<ChildrenGetAllDTO>> apiChildrensGetAllChildrenClassesGet() async
    test('test apiChildrensGetAllChildrenClassesGet', () async {
      // TODO
    });

    //Future<List<Children>> apiChildrensGetAllGet() async
    test('test apiChildrensGetAllGet', () async {
      // TODO
    });

    //Future apiChildrensGetChildFromChildIdIdGet(int id) async
    test('test apiChildrensGetChildFromChildIdIdGet', () async {
      // TODO
    });

    //Future apiChildrensGetChildrenByParentIdGet({ String authorization }) async
    test('test apiChildrensGetChildrenByParentIdGet', () async {
      // TODO
    });
  });
}
