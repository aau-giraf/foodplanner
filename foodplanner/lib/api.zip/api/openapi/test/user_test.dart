//
// AUTO-GENERATED FILE, DO NOT MODIFY!
//
// @dart=2.18

// ignore_for_file: unused_element, unused_import
// ignore_for_file: always_put_required_named_parameters_first
// ignore_for_file: constant_identifier_names
// ignore_for_file: lines_longer_than_80_chars

import 'package:foodplanner_api/api.dart';
import 'package:test/test.dart';

// tests for User
void main() {
  // final instance = User();

  group('test User', () {
    // String firstName
    test('to test the property `firstName`', () async {
      // TODO
    });

    // String lastName
    test('to test the property `lastName`', () async {
      // TODO
    });

    // String email
    test('to test the property `email`', () async {
      // TODO
    });

    // String password
    test('to test the property `password`', () async {
      // TODO
    });

    // String role
    test('to test the property `role`', () async {
      // TODO
    });

    // int id
    test('to test the property `id`', () async {
      // TODO
    });

    // bool roleApproved
    test('to test the property `roleApproved`', () async {
      // TODO
    });

    // String pinCode
    test('to test the property `pinCode`', () async {
      // TODO
    });

    // bool archived
    test('to test the property `archived`', () async {
      // TODO
    });
  });
}
