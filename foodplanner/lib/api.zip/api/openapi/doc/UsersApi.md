# foodplanner_api.api.UsersApi

## Load the API package
```dart
import 'package:foodplanner_api/api.dart';
```

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiUsersCheckPinCodePost**](UsersApi.md#apiuserscheckpincodepost) | **POST** /api/Users/CheckPinCode | 
[**apiUsersCreatePost**](UsersApi.md#apiuserscreatepost) | **POST** /api/Users/Create | 
[**apiUsersGetBearerTestGet**](UsersApi.md#apiusersgetbearertestget) | **GET** /api/Users/GetBearerTest | 
[**apiUsersGetLoggedInGet**](UsersApi.md#apiusersgetloggedinget) | **GET** /api/Users/GetLoggedIn | 
[**apiUsersHasPinCodeGet**](UsersApi.md#apiusershaspincodeget) | **GET** /api/Users/HasPinCode | 
[**apiUsersLoginPost**](UsersApi.md#apiusersloginpost) | **POST** /api/Users/Login | 
[**apiUsersUpdateLoggedInPut**](UsersApi.md#apiusersupdateloggedinput) | **PUT** /api/Users/UpdateLoggedIn | 
[**apiUsersUpdatePasswordPut**](UsersApi.md#apiusersupdatepasswordput) | **PUT** /api/Users/UpdatePassword | 
[**apiUsersUpdatePinCodePut**](UsersApi.md#apiusersupdatepincodeput) | **PUT** /api/Users/UpdatePinCode | 


# **apiUsersCheckPinCodePost**
> String apiUsersCheckPinCodePost(authorization, pincode)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = UsersApi();
final authorization = authorization_example; // String | 
final pincode = Pincode(); // Pincode | 

try {
    final result = api_instance.apiUsersCheckPinCodePost(authorization, pincode);
    print(result);
} catch (e) {
    print('Exception when calling UsersApi->apiUsersCheckPinCodePost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 
 **pincode** | [**Pincode**](Pincode.md)|  | [optional] 

### Return type

**String**

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiUsersCreatePost**
> String apiUsersCreatePost(userCreateDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = UsersApi();
final userCreateDTO = UserCreateDTO(); // UserCreateDTO | 

try {
    final result = api_instance.apiUsersCreatePost(userCreateDTO);
    print(result);
} catch (e) {
    print('Exception when calling UsersApi->apiUsersCreatePost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **userCreateDTO** | [**UserCreateDTO**](UserCreateDTO.md)|  | [optional] 

### Return type

**String**

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiUsersGetBearerTestGet**
> String apiUsersGetBearerTestGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = UsersApi();

try {
    final result = api_instance.apiUsersGetBearerTestGet();
    print(result);
} catch (e) {
    print('Exception when calling UsersApi->apiUsersGetBearerTestGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

**String**

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiUsersGetLoggedInGet**
> apiUsersGetLoggedInGet(authorization)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = UsersApi();
final authorization = authorization_example; // String | 

try {
    api_instance.apiUsersGetLoggedInGet(authorization);
} catch (e) {
    print('Exception when calling UsersApi->apiUsersGetLoggedInGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiUsersHasPinCodeGet**
> apiUsersHasPinCodeGet(authorization)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = UsersApi();
final authorization = authorization_example; // String | 

try {
    api_instance.apiUsersHasPinCodeGet(authorization);
} catch (e) {
    print('Exception when calling UsersApi->apiUsersHasPinCodeGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiUsersLoginPost**
> String apiUsersLoginPost(login)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = UsersApi();
final login = Login(); // Login | 

try {
    final result = api_instance.apiUsersLoginPost(login);
    print(result);
} catch (e) {
    print('Exception when calling UsersApi->apiUsersLoginPost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **login** | [**Login**](Login.md)|  | [optional] 

### Return type

**String**

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiUsersUpdateLoggedInPut**
> apiUsersUpdateLoggedInPut(authorization, userUpdateDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = UsersApi();
final authorization = authorization_example; // String | 
final userUpdateDTO = UserUpdateDTO(); // UserUpdateDTO | 

try {
    api_instance.apiUsersUpdateLoggedInPut(authorization, userUpdateDTO);
} catch (e) {
    print('Exception when calling UsersApi->apiUsersUpdateLoggedInPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 
 **userUpdateDTO** | [**UserUpdateDTO**](UserUpdateDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiUsersUpdatePasswordPut**
> apiUsersUpdatePasswordPut(authorization, password)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = UsersApi();
final authorization = authorization_example; // String | 
final password = Password(); // Password | 

try {
    api_instance.apiUsersUpdatePasswordPut(authorization, password);
} catch (e) {
    print('Exception when calling UsersApi->apiUsersUpdatePasswordPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 
 **password** | [**Password**](Password.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiUsersUpdatePinCodePut**
> apiUsersUpdatePinCodePut(authorization, pincode)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = UsersApi();
final authorization = authorization_example; // String | 
final pincode = Pincode(); // Pincode | 

try {
    api_instance.apiUsersUpdatePinCodePut(authorization, pincode);
} catch (e) {
    print('Exception when calling UsersApi->apiUsersUpdatePinCodePut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 
 **pincode** | [**Pincode**](Pincode.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

