# foodplanner_api.api.ImagesApi

## Load the API package
```dart
import 'package:foodplanner_api/api.dart';
```

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiImagesDeleteImagesDelete**](ImagesApi.md#apiimagesdeleteimagesdelete) | **DELETE** /api/Images/DeleteImages | 
[**apiImagesGetFoodImageGet**](ImagesApi.md#apiimagesgetfoodimageget) | **GET** /api/Images/GetFoodImage | 
[**apiImagesGetPresignedImageLinkGet**](ImagesApi.md#apiimagesgetpresignedimagelinkget) | **GET** /api/Images/GetPresignedImageLink | 
[**apiImagesUploadImagePost**](ImagesApi.md#apiimagesuploadimagepost) | **POST** /api/Images/UploadImage | 


# **apiImagesDeleteImagesDelete**
> apiImagesDeleteImagesDelete(foodImageIds)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ImagesApi();
final foodImageIds = []; // List<int> | 

try {
    api_instance.apiImagesDeleteImagesDelete(foodImageIds);
} catch (e) {
    print('Exception when calling ImagesApi->apiImagesDeleteImagesDelete: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **foodImageIds** | [**List<int>**](int.md)|  | [optional] [default to const []]

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiImagesGetFoodImageGet**
> FoodImage apiImagesGetFoodImageGet(foodImageId)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ImagesApi();
final foodImageId = 56; // int | 

try {
    final result = api_instance.apiImagesGetFoodImageGet(foodImageId);
    print(result);
} catch (e) {
    print('Exception when calling ImagesApi->apiImagesGetFoodImageGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **foodImageId** | **int**|  | [optional] 

### Return type

[**FoodImage**](FoodImage.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiImagesGetPresignedImageLinkGet**
> String apiImagesGetPresignedImageLinkGet(foodImageId)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ImagesApi();
final foodImageId = 56; // int | 

try {
    final result = api_instance.apiImagesGetPresignedImageLinkGet(foodImageId);
    print(result);
} catch (e) {
    print('Exception when calling ImagesApi->apiImagesGetPresignedImageLinkGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **foodImageId** | **int**|  | [optional] 

### Return type

**String**

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiImagesUploadImagePost**
> apiImagesUploadImagePost(authorization, imageFile)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ImagesApi();
final authorization = authorization_example; // String | 
final imageFile = BINARY_DATA_HERE; // MultipartFile | 

try {
    api_instance.apiImagesUploadImagePost(authorization, imageFile);
} catch (e) {
    print('Exception when calling ImagesApi->apiImagesUploadImagePost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 
 **imageFile** | **MultipartFile**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: multipart/form-data
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

