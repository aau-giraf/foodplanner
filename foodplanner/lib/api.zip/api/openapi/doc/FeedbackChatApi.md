# foodplanner_api.api.FeedbackChatApi

## Load the API package
```dart
import 'package:foodplanner_api/api.dart';
```

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiFeedbackChatAddMessagePost**](FeedbackChatApi.md#apifeedbackchataddmessagepost) | **POST** /api/FeedbackChat/AddMessage | 
[**apiFeedbackChatArchiveMessageMessageIdDelete**](FeedbackChatApi.md#apifeedbackchatarchivemessagemessageiddelete) | **DELETE** /api/FeedbackChat/ArchiveMessage/{messageId} | 
[**apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGet**](FeedbackChatApi.md#apifeedbackchatgetchatthreadidanduseridfromchildidandtokenchildidget) | **GET** /api/FeedbackChat/GetChatThreadIdAndUserIdFromChildIdAndToken/{childId} | 
[**apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGet**](FeedbackChatApi.md#apifeedbackchatgetchatthreadidanduseridfromtokenget) | **GET** /api/FeedbackChat/GetChatThreadIdAndUserIdFromToken | 
[**apiFeedbackChatGetMessagesChatThreadIdGet**](FeedbackChatApi.md#apifeedbackchatgetmessageschatthreadidget) | **GET** /api/FeedbackChat/GetMessages/{chatThreadId} | 
[**apiFeedbackChatUpdateMessagePut**](FeedbackChatApi.md#apifeedbackchatupdatemessageput) | **PUT** /api/FeedbackChat/UpdateMessage | 


# **apiFeedbackChatAddMessagePost**
> apiFeedbackChatAddMessagePost(authorization, addMessageDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = FeedbackChatApi();
final authorization = authorization_example; // String | 
final addMessageDTO = AddMessageDTO(); // AddMessageDTO | 

try {
    api_instance.apiFeedbackChatAddMessagePost(authorization, addMessageDTO);
} catch (e) {
    print('Exception when calling FeedbackChatApi->apiFeedbackChatAddMessagePost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 
 **addMessageDTO** | [**AddMessageDTO**](AddMessageDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiFeedbackChatArchiveMessageMessageIdDelete**
> apiFeedbackChatArchiveMessageMessageIdDelete(messageId)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = FeedbackChatApi();
final messageId = 56; // int | 

try {
    api_instance.apiFeedbackChatArchiveMessageMessageIdDelete(messageId);
} catch (e) {
    print('Exception when calling FeedbackChatApi->apiFeedbackChatArchiveMessageMessageIdDelete: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **messageId** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGet**
> apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGet(childId, authorization)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = FeedbackChatApi();
final childId = 56; // int | 
final authorization = authorization_example; // String | 

try {
    api_instance.apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGet(childId, authorization);
} catch (e) {
    print('Exception when calling FeedbackChatApi->apiFeedbackChatGetChatThreadIdAndUserIdFromChildIdAndTokenChildIdGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **childId** | **int**|  | 
 **authorization** | **String**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGet**
> apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGet(authorization)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = FeedbackChatApi();
final authorization = authorization_example; // String | 

try {
    api_instance.apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGet(authorization);
} catch (e) {
    print('Exception when calling FeedbackChatApi->apiFeedbackChatGetChatThreadIdAndUserIdFromTokenGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiFeedbackChatGetMessagesChatThreadIdGet**
> apiFeedbackChatGetMessagesChatThreadIdGet(chatThreadId)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = FeedbackChatApi();
final chatThreadId = 56; // int | 

try {
    api_instance.apiFeedbackChatGetMessagesChatThreadIdGet(chatThreadId);
} catch (e) {
    print('Exception when calling FeedbackChatApi->apiFeedbackChatGetMessagesChatThreadIdGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chatThreadId** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiFeedbackChatUpdateMessagePut**
> apiFeedbackChatUpdateMessagePut(updateMessageDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = FeedbackChatApi();
final updateMessageDTO = UpdateMessageDTO(); // UpdateMessageDTO | 

try {
    api_instance.apiFeedbackChatUpdateMessagePut(updateMessageDTO);
} catch (e) {
    print('Exception when calling FeedbackChatApi->apiFeedbackChatUpdateMessagePut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **updateMessageDTO** | [**UpdateMessageDTO**](UpdateMessageDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

