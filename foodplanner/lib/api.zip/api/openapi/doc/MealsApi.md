# foodplanner_api.api.MealsApi

## Load the API package
```dart
import 'package:foodplanner_api/api.dart';
```

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiMealsCreatePost**](MealsApi.md#apimealscreatepost) | **POST** /api/Meals/Create | 
[**apiMealsDeleteIdDelete**](MealsApi.md#apimealsdeleteiddelete) | **DELETE** /api/Meals/Delete/{id} | 
[**apiMealsGetAllByUserDateGet**](MealsApi.md#apimealsgetallbyuserdateget) | **GET** /api/Meals/GetAllByUser/{date} | 
[**apiMealsGetAllGet**](MealsApi.md#apimealsgetallget) | **GET** /api/Meals/GetAll | 
[**apiMealsGetIdGet**](MealsApi.md#apimealsgetidget) | **GET** /api/Meals/Get/{id} | 
[**apiMealsTeacherGetUserMealsGet**](MealsApi.md#apimealsteachergetusermealsget) | **GET** /api/Meals/TeacherGetUserMeals | 
[**apiMealsUpdateIdPut**](MealsApi.md#apimealsupdateidput) | **PUT** /api/Meals/Update/{id} | 


# **apiMealsCreatePost**
> apiMealsCreatePost(authorization, mealCreateDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = MealsApi();
final authorization = authorization_example; // String | 
final mealCreateDTO = MealCreateDTO(); // MealCreateDTO | 

try {
    api_instance.apiMealsCreatePost(authorization, mealCreateDTO);
} catch (e) {
    print('Exception when calling MealsApi->apiMealsCreatePost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 
 **mealCreateDTO** | [**MealCreateDTO**](MealCreateDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiMealsDeleteIdDelete**
> apiMealsDeleteIdDelete(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = MealsApi();
final id = 56; // int | 

try {
    api_instance.apiMealsDeleteIdDelete(id);
} catch (e) {
    print('Exception when calling MealsApi->apiMealsDeleteIdDelete: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiMealsGetAllByUserDateGet**
> apiMealsGetAllByUserDateGet(date, authorization)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = MealsApi();
final date = date_example; // String | 
final authorization = authorization_example; // String | 

try {
    api_instance.apiMealsGetAllByUserDateGet(date, authorization);
} catch (e) {
    print('Exception when calling MealsApi->apiMealsGetAllByUserDateGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **date** | **String**|  | 
 **authorization** | **String**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiMealsGetAllGet**
> apiMealsGetAllGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = MealsApi();

try {
    api_instance.apiMealsGetAllGet();
} catch (e) {
    print('Exception when calling MealsApi->apiMealsGetAllGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiMealsGetIdGet**
> apiMealsGetIdGet(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = MealsApi();
final id = 56; // int | 

try {
    api_instance.apiMealsGetIdGet(id);
} catch (e) {
    print('Exception when calling MealsApi->apiMealsGetIdGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiMealsTeacherGetUserMealsGet**
> apiMealsTeacherGetUserMealsGet(date, id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = MealsApi();
final date = date_example; // String | 
final id = 56; // int | 

try {
    api_instance.apiMealsTeacherGetUserMealsGet(date, id);
} catch (e) {
    print('Exception when calling MealsApi->apiMealsTeacherGetUserMealsGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **date** | **String**|  | [optional] 
 **id** | **int**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiMealsUpdateIdPut**
> apiMealsUpdateIdPut(id, authorization, meal)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = MealsApi();
final id = 56; // int | 
final authorization = authorization_example; // String | 
final meal = Meal(); // Meal | 

try {
    api_instance.apiMealsUpdateIdPut(id, authorization, meal);
} catch (e) {
    print('Exception when calling MealsApi->apiMealsUpdateIdPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 
 **authorization** | **String**|  | [optional] 
 **meal** | [**Meal**](Meal.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

