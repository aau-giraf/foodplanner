# foodplanner_api.api.ChildrensApi

## Load the API package
```dart
import 'package:foodplanner_api/api.dart';
```

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiChildrensCreatePost**](ChildrensApi.md#apichildrenscreatepost) | **POST** /api/Childrens/Create | 
[**apiChildrensDeleteIdDelete**](ChildrensApi.md#apichildrensdeleteiddelete) | **DELETE** /api/Childrens/Delete/{id} | 
[**apiChildrensGetAllChildrenClassesGet**](ChildrensApi.md#apichildrensgetallchildrenclassesget) | **GET** /api/Childrens/GetAllChildrenClasses | 
[**apiChildrensGetAllGet**](ChildrensApi.md#apichildrensgetallget) | **GET** /api/Childrens/GetAll | 
[**apiChildrensGetChildFromChildIdIdGet**](ChildrensApi.md#apichildrensgetchildfromchildididget) | **GET** /api/Childrens/GetChildFromChildId/{id} | 
[**apiChildrensGetChildrenByParentIdGet**](ChildrensApi.md#apichildrensgetchildrenbyparentidget) | **GET** /api/Childrens/GetChildrenByParentId | 


# **apiChildrensCreatePost**
> apiChildrensCreatePost(authorization, childrenCreateDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ChildrensApi();
final authorization = authorization_example; // String | 
final childrenCreateDTO = ChildrenCreateDTO(); // ChildrenCreateDTO | 

try {
    api_instance.apiChildrensCreatePost(authorization, childrenCreateDTO);
} catch (e) {
    print('Exception when calling ChildrensApi->apiChildrensCreatePost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 
 **childrenCreateDTO** | [**ChildrenCreateDTO**](ChildrenCreateDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiChildrensDeleteIdDelete**
> apiChildrensDeleteIdDelete(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ChildrensApi();
final id = 56; // int | 

try {
    api_instance.apiChildrensDeleteIdDelete(id);
} catch (e) {
    print('Exception when calling ChildrensApi->apiChildrensDeleteIdDelete: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiChildrensGetAllChildrenClassesGet**
> List<ChildrenGetAllDTO> apiChildrensGetAllChildrenClassesGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ChildrensApi();

try {
    final result = api_instance.apiChildrensGetAllChildrenClassesGet();
    print(result);
} catch (e) {
    print('Exception when calling ChildrensApi->apiChildrensGetAllChildrenClassesGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<ChildrenGetAllDTO>**](ChildrenGetAllDTO.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiChildrensGetAllGet**
> List<Children> apiChildrensGetAllGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ChildrensApi();

try {
    final result = api_instance.apiChildrensGetAllGet();
    print(result);
} catch (e) {
    print('Exception when calling ChildrensApi->apiChildrensGetAllGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<Children>**](Children.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiChildrensGetChildFromChildIdIdGet**
> apiChildrensGetChildFromChildIdIdGet(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ChildrensApi();
final id = 56; // int | 

try {
    api_instance.apiChildrensGetChildFromChildIdIdGet(id);
} catch (e) {
    print('Exception when calling ChildrensApi->apiChildrensGetChildFromChildIdIdGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiChildrensGetChildrenByParentIdGet**
> apiChildrensGetChildrenByParentIdGet(authorization)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ChildrensApi();
final authorization = authorization_example; // String | 

try {
    api_instance.apiChildrensGetChildrenByParentIdGet(authorization);
} catch (e) {
    print('Exception when calling ChildrensApi->apiChildrensGetChildrenByParentIdGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

