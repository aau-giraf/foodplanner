# foodplanner_api.model.FoodImage

## Load the model package
```dart
import 'package:foodplanner_api/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**imageId** | **String** |  | [optional] 
**userId** | **int** |  | [optional] 
**imageName** | **String** |  | [optional] 
**imageFileType** | **String** |  | [optional] 
**size** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


