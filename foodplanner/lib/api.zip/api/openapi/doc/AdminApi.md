# foodplanner_api.api.AdminApi

## Load the API package
```dart
import 'package:foodplanner_api/api.dart';
```

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiAdminDeleteIdDelete**](AdminApi.md#apiadmindeleteiddelete) | **DELETE** /api/Admin/Delete/{id} | 
[**apiAdminGetAllChildrenGet**](AdminApi.md#apiadmingetallchildrenget) | **GET** /api/Admin/GetAllChildren | 
[**apiAdminGetAllGet**](AdminApi.md#apiadmingetallget) | **GET** /api/Admin/GetAll | 
[**apiAdminGetIdGet**](AdminApi.md#apiadmingetidget) | **GET** /api/Admin/Get/{id} | 
[**apiAdminGetNotApprovedGet**](AdminApi.md#apiadmingetnotapprovedget) | **GET** /api/Admin/GetNotApproved | 
[**apiAdminGetNotArchivedGet**](AdminApi.md#apiadmingetnotarchivedget) | **GET** /api/Admin/GetNotArchived | 
[**apiAdminUpdateArchivedIdPut**](AdminApi.md#apiadminupdatearchivedidput) | **PUT** /api/Admin/UpdateArchived/{id} | 
[**apiAdminUpdateChildPut**](AdminApi.md#apiadminupdatechildput) | **PUT** /api/Admin/UpdateChild | 
[**apiAdminUpdateIdPut**](AdminApi.md#apiadminupdateidput) | **PUT** /api/Admin/Update/{id} | 
[**apiAdminUpdateRoleApprovedIdPut**](AdminApi.md#apiadminupdateroleapprovedidput) | **PUT** /api/Admin/UpdateRoleApproved/{id} | 


# **apiAdminDeleteIdDelete**
> apiAdminDeleteIdDelete(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();
final id = 56; // int | 

try {
    api_instance.apiAdminDeleteIdDelete(id);
} catch (e) {
    print('Exception when calling AdminApi->apiAdminDeleteIdDelete: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiAdminGetAllChildrenGet**
> apiAdminGetAllChildrenGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();

try {
    api_instance.apiAdminGetAllChildrenGet();
} catch (e) {
    print('Exception when calling AdminApi->apiAdminGetAllChildrenGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiAdminGetAllGet**
> List<UserDTO> apiAdminGetAllGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();

try {
    final result = api_instance.apiAdminGetAllGet();
    print(result);
} catch (e) {
    print('Exception when calling AdminApi->apiAdminGetAllGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List<UserDTO>**](UserDTO.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiAdminGetIdGet**
> List<UserDTO> apiAdminGetIdGet(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();
final id = 56; // int | 

try {
    final result = api_instance.apiAdminGetIdGet(id);
    print(result);
} catch (e) {
    print('Exception when calling AdminApi->apiAdminGetIdGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

[**List<UserDTO>**](UserDTO.md)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiAdminGetNotApprovedGet**
> apiAdminGetNotApprovedGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();

try {
    api_instance.apiAdminGetNotApprovedGet();
} catch (e) {
    print('Exception when calling AdminApi->apiAdminGetNotApprovedGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiAdminGetNotArchivedGet**
> apiAdminGetNotArchivedGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();

try {
    api_instance.apiAdminGetNotArchivedGet();
} catch (e) {
    print('Exception when calling AdminApi->apiAdminGetNotArchivedGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiAdminUpdateArchivedIdPut**
> apiAdminUpdateArchivedIdPut(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();
final id = 56; // int | 

try {
    api_instance.apiAdminUpdateArchivedIdPut(id);
} catch (e) {
    print('Exception when calling AdminApi->apiAdminUpdateArchivedIdPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiAdminUpdateChildPut**
> apiAdminUpdateChildPut(children)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();
final children = Children(); // Children | 

try {
    api_instance.apiAdminUpdateChildPut(children);
} catch (e) {
    print('Exception when calling AdminApi->apiAdminUpdateChildPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **children** | [**Children**](Children.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiAdminUpdateIdPut**
> apiAdminUpdateIdPut(id, user)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();
final id = 56; // int | 
final user = User(); // User | 

try {
    api_instance.apiAdminUpdateIdPut(id, user);
} catch (e) {
    print('Exception when calling AdminApi->apiAdminUpdateIdPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 
 **user** | [**User**](User.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiAdminUpdateRoleApprovedIdPut**
> apiAdminUpdateRoleApprovedIdPut(id, userRoleDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = AdminApi();
final id = 56; // int | 
final userRoleDTO = UserRoleDTO(); // UserRoleDTO | 

try {
    api_instance.apiAdminUpdateRoleApprovedIdPut(id, userRoleDTO);
} catch (e) {
    print('Exception when calling AdminApi->apiAdminUpdateRoleApprovedIdPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 
 **userRoleDTO** | [**UserRoleDTO**](UserRoleDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

