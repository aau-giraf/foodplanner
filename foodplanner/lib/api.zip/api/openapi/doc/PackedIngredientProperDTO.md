# foodplanner_api.model.PackedIngredientProperDTO

## Load the model package
```dart
import 'package:foodplanner_api/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**mealId** | **int** |  | [optional] 
**ingredientId** | **int** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


