# foodplanner_api.api.PackedIngredientApi

## Load the API package
```dart
import 'package:foodplanner_api/api.dart';
```

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiPackedIngredientCreatePost**](PackedIngredientApi.md#apipackedingredientcreatepost) | **POST** /api/PackedIngredient/Create | 
[**apiPackedIngredientDeleteIdDelete**](PackedIngredientApi.md#apipackedingredientdeleteiddelete) | **DELETE** /api/PackedIngredient/Delete/{id} | 
[**apiPackedIngredientGetAllGet**](PackedIngredientApi.md#apipackedingredientgetallget) | **GET** /api/PackedIngredient/GetAll | 
[**apiPackedIngredientGetIdGet**](PackedIngredientApi.md#apipackedingredientgetidget) | **GET** /api/PackedIngredient/Get/{id} | 
[**apiPackedIngredientUpdateIdPut**](PackedIngredientApi.md#apipackedingredientupdateidput) | **PUT** /api/PackedIngredient/Update/{id} | 
[**apiPackedIngredientUpdateOrderPut**](PackedIngredientApi.md#apipackedingredientupdateorderput) | **PUT** /api/PackedIngredient/UpdateOrder | 


# **apiPackedIngredientCreatePost**
> apiPackedIngredientCreatePost(packedIngredientProperDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = PackedIngredientApi();
final packedIngredientProperDTO = PackedIngredientProperDTO(); // PackedIngredientProperDTO | 

try {
    api_instance.apiPackedIngredientCreatePost(packedIngredientProperDTO);
} catch (e) {
    print('Exception when calling PackedIngredientApi->apiPackedIngredientCreatePost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **packedIngredientProperDTO** | [**PackedIngredientProperDTO**](PackedIngredientProperDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiPackedIngredientDeleteIdDelete**
> apiPackedIngredientDeleteIdDelete(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = PackedIngredientApi();
final id = 56; // int | 

try {
    api_instance.apiPackedIngredientDeleteIdDelete(id);
} catch (e) {
    print('Exception when calling PackedIngredientApi->apiPackedIngredientDeleteIdDelete: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiPackedIngredientGetAllGet**
> apiPackedIngredientGetAllGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = PackedIngredientApi();

try {
    api_instance.apiPackedIngredientGetAllGet();
} catch (e) {
    print('Exception when calling PackedIngredientApi->apiPackedIngredientGetAllGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiPackedIngredientGetIdGet**
> apiPackedIngredientGetIdGet(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = PackedIngredientApi();
final id = 56; // int | 

try {
    api_instance.apiPackedIngredientGetIdGet(id);
} catch (e) {
    print('Exception when calling PackedIngredientApi->apiPackedIngredientGetIdGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiPackedIngredientUpdateIdPut**
> apiPackedIngredientUpdateIdPut(id, packedIngredient)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = PackedIngredientApi();
final id = 56; // int | 
final packedIngredient = PackedIngredient(); // PackedIngredient | 

try {
    api_instance.apiPackedIngredientUpdateIdPut(id, packedIngredient);
} catch (e) {
    print('Exception when calling PackedIngredientApi->apiPackedIngredientUpdateIdPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 
 **packedIngredient** | [**PackedIngredient**](PackedIngredient.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiPackedIngredientUpdateOrderPut**
> apiPackedIngredientUpdateOrderPut(packedIngredient)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = PackedIngredientApi();
final packedIngredient = [List<PackedIngredient>()]; // List<PackedIngredient> | 

try {
    api_instance.apiPackedIngredientUpdateOrderPut(packedIngredient);
} catch (e) {
    print('Exception when calling PackedIngredientApi->apiPackedIngredientUpdateOrderPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **packedIngredient** | [**List<PackedIngredient>**](PackedIngredient.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

