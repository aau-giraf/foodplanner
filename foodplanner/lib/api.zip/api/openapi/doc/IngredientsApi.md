# foodplanner_api.api.IngredientsApi

## Load the API package
```dart
import 'package:foodplanner_api/api.dart';
```

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiIngredientsCreatePost**](IngredientsApi.md#apiingredientscreatepost) | **POST** /api/Ingredients/Create | 
[**apiIngredientsDeleteIdDelete**](IngredientsApi.md#apiingredientsdeleteiddelete) | **DELETE** /api/Ingredients/Delete/{id} | 
[**apiIngredientsGetAllByUserGet**](IngredientsApi.md#apiingredientsgetallbyuserget) | **GET** /api/Ingredients/GetAllByUser | 
[**apiIngredientsGetAllGet**](IngredientsApi.md#apiingredientsgetallget) | **GET** /api/Ingredients/GetAll | 
[**apiIngredientsGetIdGet**](IngredientsApi.md#apiingredientsgetidget) | **GET** /api/Ingredients/Get/{id} | 
[**apiIngredientsUpdateIdPut**](IngredientsApi.md#apiingredientsupdateidput) | **PUT** /api/Ingredients/Update/{id} | 


# **apiIngredientsCreatePost**
> apiIngredientsCreatePost(authorization, ingredientDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = IngredientsApi();
final authorization = authorization_example; // String | 
final ingredientDTO = IngredientDTO(); // IngredientDTO | 

try {
    api_instance.apiIngredientsCreatePost(authorization, ingredientDTO);
} catch (e) {
    print('Exception when calling IngredientsApi->apiIngredientsCreatePost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 
 **ingredientDTO** | [**IngredientDTO**](IngredientDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiIngredientsDeleteIdDelete**
> apiIngredientsDeleteIdDelete(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = IngredientsApi();
final id = 56; // int | 

try {
    api_instance.apiIngredientsDeleteIdDelete(id);
} catch (e) {
    print('Exception when calling IngredientsApi->apiIngredientsDeleteIdDelete: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiIngredientsGetAllByUserGet**
> apiIngredientsGetAllByUserGet(authorization)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = IngredientsApi();
final authorization = authorization_example; // String | 

try {
    api_instance.apiIngredientsGetAllByUserGet(authorization);
} catch (e) {
    print('Exception when calling IngredientsApi->apiIngredientsGetAllByUserGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **authorization** | **String**|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiIngredientsGetAllGet**
> apiIngredientsGetAllGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = IngredientsApi();

try {
    api_instance.apiIngredientsGetAllGet();
} catch (e) {
    print('Exception when calling IngredientsApi->apiIngredientsGetAllGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiIngredientsGetIdGet**
> apiIngredientsGetIdGet(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = IngredientsApi();
final id = 56; // int | 

try {
    api_instance.apiIngredientsGetIdGet(id);
} catch (e) {
    print('Exception when calling IngredientsApi->apiIngredientsGetIdGet: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiIngredientsUpdateIdPut**
> apiIngredientsUpdateIdPut(id, ingredient)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = IngredientsApi();
final id = 56; // int | 
final ingredient = Ingredient(); // Ingredient | 

try {
    api_instance.apiIngredientsUpdateIdPut(id, ingredient);
} catch (e) {
    print('Exception when calling IngredientsApi->apiIngredientsUpdateIdPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 
 **ingredient** | [**Ingredient**](Ingredient.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

