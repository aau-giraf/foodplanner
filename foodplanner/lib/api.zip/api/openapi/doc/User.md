# foodplanner_api.model.User

## Load the model package
```dart
import 'package:foodplanner_api/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstName** | **String** |  | 
**lastName** | **String** |  | 
**email** | **String** |  | 
**password** | **String** |  | 
**role** | **String** |  | 
**id** | **int** |  | [optional] 
**roleApproved** | **bool** |  | [optional] 
**pinCode** | **String** |  | [optional] 
**archived** | **bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


