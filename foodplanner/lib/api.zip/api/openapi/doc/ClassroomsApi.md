# foodplanner_api.api.ClassroomsApi

## Load the API package
```dart
import 'package:foodplanner_api/api.dart';
```

All URIs are relative to *http://localhost:8080*

Method | HTTP request | Description
------------- | ------------- | -------------
[**apiClassroomsCreatePost**](ClassroomsApi.md#apiclassroomscreatepost) | **POST** /api/Classrooms/Create | 
[**apiClassroomsDeleteIdDelete**](ClassroomsApi.md#apiclassroomsdeleteiddelete) | **DELETE** /api/Classrooms/Delete/{id} | 
[**apiClassroomsGetAllGet**](ClassroomsApi.md#apiclassroomsgetallget) | **GET** /api/Classrooms/GetAll | 
[**apiClassroomsUpdateIdPut**](ClassroomsApi.md#apiclassroomsupdateidput) | **PUT** /api/Classrooms/Update/{id} | 


# **apiClassroomsCreatePost**
> apiClassroomsCreatePost(createClassroomDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ClassroomsApi();
final createClassroomDTO = CreateClassroomDTO(); // CreateClassroomDTO | 

try {
    api_instance.apiClassroomsCreatePost(createClassroomDTO);
} catch (e) {
    print('Exception when calling ClassroomsApi->apiClassroomsCreatePost: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **createClassroomDTO** | [**CreateClassroomDTO**](CreateClassroomDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiClassroomsDeleteIdDelete**
> apiClassroomsDeleteIdDelete(id)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ClassroomsApi();
final id = 56; // int | 

try {
    api_instance.apiClassroomsDeleteIdDelete(id);
} catch (e) {
    print('Exception when calling ClassroomsApi->apiClassroomsDeleteIdDelete: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiClassroomsGetAllGet**
> apiClassroomsGetAllGet()



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ClassroomsApi();

try {
    api_instance.apiClassroomsGetAllGet();
} catch (e) {
    print('Exception when calling ClassroomsApi->apiClassroomsGetAllGet: $e\n');
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **apiClassroomsUpdateIdPut**
> apiClassroomsUpdateIdPut(id, createClassroomDTO)



### Example
```dart
import 'package:foodplanner_api/api.dart';
// TODO Configure API key authorization: Bearer
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKey = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//defaultApiClient.getAuthentication<ApiKeyAuth>('Bearer').apiKeyPrefix = 'Bearer';

final api_instance = ClassroomsApi();
final id = 56; // int | 
final createClassroomDTO = CreateClassroomDTO(); // CreateClassroomDTO | 

try {
    api_instance.apiClassroomsUpdateIdPut(id, createClassroomDTO);
} catch (e) {
    print('Exception when calling ClassroomsApi->apiClassroomsUpdateIdPut: $e\n');
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 
 **createClassroomDTO** | [**CreateClassroomDTO**](CreateClassroomDTO.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json, text/json, application/*+json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

